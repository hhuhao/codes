#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){return a<b?a=b,1:0;}
template<class T> inline bool chkmin(T& a,T b){return a>b?a=b,1:0;}
template<typename T> inline T& read(T& x){
	static char c; bool flag=0;
	while(!isdigit(c=getchar()));
	for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
	if(flag) x=-x;
	return x;
}
const int maxn=1000010,maxm=210,maxh=1000;

struct node{
	int l,r;
	bool operator < (const node& rhs) const{
		return l==rhs.l?r>rhs.r:l<rhs.l;
	}
}c[maxm];
int n,m,h,k,a[maxn],sum[maxh+10],ans;
bool vis[maxn];
int main(){
	freopen("apple3.in","r",stdin);
	freopen("BF.out","w",stdout);
	read(n); read(m); read(h); read(k);
	for(int i=1;i<=n;i++){
		read(a[i]);
		if(a[i]==h) ++ans;
		else ++sum[a[i]];
	}
	for(int i=1;i<=m;i++){
        read(c[i].l),read(c[i].r);
        c[i].l+=h; c[i].r+=h;
    }
	for(int s=0;s<(1<<m);s++) if(__builtin_popcount(s)==k){
		memset(vis,0,sizeof vis); int tot=0;
		for(int i=1;i<=m;i++) if(s&(1<<(i-1)))
			for(int j=c[i].l;j<=min(c[i].r,maxh);j++){
				if(!vis[j]) vis[j]=1,tot+=sum[j];
			}
		chkmax(ans,tot);
	}
	cout<<ans<<endl;
	return 0;
}
