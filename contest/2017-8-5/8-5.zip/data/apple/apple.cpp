#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){return a<b?a=b,1:0;}
template<class T> inline bool chkmin(T& a,T b){return a>b?a=b,1:0;}
template<typename T> inline T& read(T& x){
	static char c; bool flag=0;
	while(!isdigit(c=getchar()));
	for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
	if(flag) x=-x;
	return x;
}
const int maxn=1000010,maxm=210,maxh=1000000;

struct node{
	int l,r;
	bool operator < (const node& rhs) const{
		return l==rhs.l?r>rhs.r:l<rhs.l;
	}
}c[maxm];
int n,m,h,k,a[maxn],sum[maxh+10],ans1,ans2,dp[maxm][maxm];
int t=0;
int main(){
	freopen("apple9.in","r",stdin);
	freopen("apple9.out","w",stdout);
	read(n); read(m); read(h); read(k);
	for(int i=1;i<=n;i++){
		read(a[i]);
		if(a[i]==h) ++ans1;
		else ++sum[a[i]];
	}
	for(int i=1;i<=maxh;i++) sum[i]+=sum[i-1];
	for(int i=1;i<=m;i++){
		read(c[i].l)+=h,read(c[i].r)+=h;
		chkmin(c[i].r,maxh);
	}
	sort(c+1,c+m+1); int cnt=0;
	for(int i=1;i<=m;i++) if(c[i].l<=maxh&&(!cnt||c[i].r>c[cnt].r)) c[++cnt]=c[i];
	m=cnt; chkmin(k,m);
	for(int i=1;i<=m;i++)
		for(int j=1;j<=k;j++)
			for(int i1=0;i1<m;i1++)
				chkmax(dp[i][j],dp[i1][j-1]+sum[c[i].r]-sum[max(c[i1].r,c[i].l-1)]);
	for(int i=1;i<=m;i++) chkmax(ans2,dp[i][k]);
	cout<<ans1+ans2;
	return 0;
}
