from cyaron import *
import random

for i in range(4, 7):
    io = IO(file_prefix = "apple", data_id = i)
    n = random.randint(100000, 1000000)
    m = 200
    h = random.randint(1, 300000)
    k = random.randint(40, 100)
    io.input_writeln(n, m, h, k)
    for j in range(1, n + 1):
        tmp = random.randint(1, 1000000)
        if tmp == h:
            tmp = tmp + 1
        io.input_write(tmp, separator = ' ')
    io.input_writeln()
    for j in range(1, m + 1):
        tmp = random.randint(0, 50)
        if tmp == 0:
            l = random.randint(1000000 - h + 1, 1000000)
        else:
            l = random.randint(0, 600000)
        tmp = random.randint(0, 50)
        if tmp == 0:
            r = random.randint(l + 1, min(l + 40000, 1000000))
        else:
            r = random.randint(l + 1, min(l + 7000, 1000000))
        io.input_writeln(l, r)
