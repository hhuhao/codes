from cyaron import *
import random
def myfunc(self):
    return "%d %d" % (self.start, self.end)
for i in range(4,5):
    io = IO(file_prefix = "tree", data_id = i)
    n = random.randint(90, 100)
    io.input_writeln(n)
    t = Graph.tree(n,0,0.75)
    io.input_writeln(t.to_str(shuffle = True, output = myfunc))
    io.output_gen("~/Documents/出题 by xffyjq/data/tree/tree")
