#include <bits/stdc++.h>

using namespace std;

#define rep(i, l, r) for(int i = l, i##end = r; i <= i##end; ++i)
#define drep(i, l, r) for(int i = l, i##end = r; i >= i##end; --i)
#define erep(i, u) for(int i = head[u], v = to[i]; i; i = nxt[i], v = to[i])
#define ms(a, b) memset(a, b, sizeof a)

template<class T> inline bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template<class T> inline bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

template<typename T> inline T& read(T& x)
{
    static char c; bool flag = 0;
    while(!isdigit(c = getchar())) if(c == '-') flag = 1;
    for(x = c - '0'; isdigit(c = getchar()); (x *= 10) += c - '0');
    if(flag) x = -x;
    return x;
}

typedef long long LL;

const int maxn = 100010;

int n;

LL ans, nd[maxn * 5], *p, *f[maxn], *g[maxn];

int head[maxn], nxt[maxn << 1], to[maxn << 1], e;
void ae(int x, int y) { to[++e] = y; nxt[e] = head[x]; head[x] = e; }

int dep[maxn], fa[maxn], bot[maxn];

void dfs(int u)
{
    bot[u] = u;
    erep(i, u) if(v != fa[u])
    {
        fa[v] = u; dep[v] = dep[u] + 1;
        dfs(v); if(dep[bot[v]] > dep[bot[u]]) bot[u] = bot[v];
    }
    erep(i, u) if(v != fa[u] && bot[u] != bot[v] || u == 1)
    {
        p += dep[bot[v]] - dep[u] + 1;
        f[bot[v]] = p; g[bot[v]] = ++p;
        p += (dep[bot[v]] - dep[u]) << 1 | 1;
    }
}

void dp(int u)
{
    erep(i, u) if(v != fa[u])
    {
        dp(v);
        if(bot[u] == bot[v]) f[u] = f[v] - 1, g[u] = g[v] + 1;
    }
    f[u][0] = 1; ans += g[u][0];
    erep(i, u) if(v != fa[u] && bot[u] != bot[v])
    {
        rep(j, 0, dep[bot[v]] - dep[u])
            ans += f[u][j - 1] * g[v][j] + g[u][j + 1] * f[v][j];
        rep(j, 0, dep[bot[v]] - dep[u])
        {
            g[u][j - 1] += g[v][j];
            g[u][j + 1] += f[u][j + 1] * f[v][j];
            f[u][j + 1] += f[v][j];
        }
    }
}

int main()
{
    read(n); int x, y;
    rep(i, 1, n - 1) read(x), read(y), ae(x, y), ae(y, x);
    p = nd + 1; dfs(1); dp(1);
    printf("%lld\n", ans);

    return 0;
}
