from cyaron import *
import random
for i in range(1, 2):
    io = IO(file_prefix = "fuck", data_id = i)
    n = random.randint(18, 20)
    io.input_writeln(n)
    a = Vector.random(n, ati([5,5,5]), 0)
    for j in range(n):
        io.input_writeln(a[j][0], a[j][1], a[j][2])
