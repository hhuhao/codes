#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

#define LL long long
#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100+5)
#define VAL (10000+5)

const LL P = 99991;

LL f0, f1, ra[N], f[N];
int dp[2][N][VAL];

struct Matrix{
	LL m[2][2];	
	
	Matrix(int type=0){
		Set(m, 0);
		if(type == 1){
			m[0][0] = m[1][1] = 1; return;
		}else if(type == 3){
			m[0][0] = f0; m[0][1] = f1; return;
		}else if(type == 2){
			m[0][0] = 2; m[0][1] = 1; m[1][0] = 3; return;
		}
	}

	Matrix operator *(const Matrix &rhs)const{
		Matrix ret(0);
		For(i, 0, 1) For(j, 0, 1) For(k, 0, 1){
			ret.m[i][j] = (ret.m[i][j]+m[i][k]*rhs.m[k][j]%P)%P;
		}
		return ret;
	}
};

LL Work(LL now){
	Matrix ret(3), a(2);
	
	while(now){
		if(now&1) ret = ret*a;
		a = a*a; now >>= 1ll;
	}

	return ret.m[0][1];
}

int main(){
	freopen("see.in", "r", stdin);
	freopen("see.out", "w", stdout);

	int n, k;
	LL Sum = 0ll;

	scanf("%d%d", &n, &k);
	For(i, 1, n){
		scanf("%lld", &ra[i]);
		Sum += ra[i];
	}
	scanf("%lld%lld", &f0, &f1);

	if(Sum <= 10000){
		sort(ra+1, ra+n+1);

		int L = 0, R = 0, lR, o = 0, end;
		dp[0][0][0] = 1;

		For(i, 1, n){
			end = min(i, k); o ^= 1; lR = R;
			For(j, 0, end) For(v, L, lR) dp[o][j][v] = 0;

			For(j, 0, end) For(v, L, lR) if(dp[o^1][j][v]){
				dp[o][j][v] = (dp[o][j][v]+dp[o^1][j][v])%P; 
				dp[o][j+1][v+ra[i]] += (dp[o][j+1][v+ra[i]]+dp[o^1][j][v])%P;
				R = max(R, (int)(v+ra[i]));
			}
		}

		LL ans = 0;
		f[0] = f0; f[1] = f1;
		For(i, 2, R) f[i] = (f[i-2]*3%P + f[i-1]*2%P)%P;
		For(v, L, R)
			ans = (ans+f[v]*dp[o][k][v]%P)%P;
		
		printf("%lld\n", ans);
		return 0;
	}

	LL now, ans = 0;
	int tot;
	For(nc, (1<<k)-1, (1<<n)-1){
		now = tot = 0;
		For(i, 1, n) if(nc&(1<<(i-1))) ++tot, now += ra[i];
		if(tot != k) continue;
		
		ans = (ans+Work(now))%P;
	}
	
	printf("%lld\n", ans);

	return 0;
}
