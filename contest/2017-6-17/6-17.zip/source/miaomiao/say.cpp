#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (200+2)
#define NS (1000000+2)
#define INF 0x3f3f3f3f

int rlen[N], Ans[9];
char r[N][NS];

int Solve(char *s1, int len1, char *s2, int len2, int dep){
//	printf("s1 = %s(%d) s2 = %s(%d) dep = %d\n", s1, len1, s2, len2, dep);
	if(abs(len1-len2)+dep > 8) return INF;
	if(!len1) return dep+len2; if(!len2) return dep+len1;

	int p = 0;
	while(p<len1 && p<len2 && s1[p]==s2[p]) ++p;

	if(p==len1) return dep+(len2-p);
	if(p==len2) return dep+(len1-p);
	
	return
	 min(Solve(s1+p+1, len1-p-1, s2+p+1, len2-p-1, dep+1), 
     min(Solve(s1+p, len1-p, s2+p+1, len2-p-1, dep+1),
  	     Solve(s1+p+1, len1-p-1, s2+p, len2-p, dep+1)));
}

int main(){
	freopen("say.in", "r", stdin);
	freopen("say.out", "w", stdout);

	int n;
	scanf("%d", &n);
	For(i, 1, n){
		scanf("%s", r[i]);
		rlen[i] = strlen(r[i]);
	}

	int ans;
	For(a, 1, n) For(b, 1, a-1){
		ans = Solve(r[a], rlen[a], r[b], rlen[b], 0);
		if(ans<9) ++Ans[ans];
	}
	For(i, 1, 8) printf("%d%c", Ans[i], i==8? '\n': ' ');

	return 0;
}
