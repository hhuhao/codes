#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

#define LL long long
#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (3000+5)

int en, head[N], nxt[N<<1], to[N<<1];
int n, qn, mxd, po[N];
bool vis[N];

void Add(int u, int v){
	to[++en] = v; nxt[en] = head[u]; head[u] = en;
}

void Dfs(int now, int F, int D){
	vis[now] = true;
	if(D == mxd) return;
	
	for(int i = head[now]; i; i = nxt[i]){
		if(to[i] == F) continue;
		Dfs(to[i], now, D+1);
	}
}

bool Check(){
	Set(vis, 0);
	For(i, 1, qn) Dfs(po[i], 0, 0);
	
	For(i, 1, n) if(!vis[i]) return true;
	return false;
}

int main(){
	freopen("do.in", "r", stdin);
	freopen("do.out", "w", stdout);

	int q, u, v;
	scanf("%d%d", &n, &q);

	For(i, 1, n-1){
		scanf("%d%d", &u, &v);
		Add(u, v); Add(v, u);
	}

	int L, R, mid;
	while(q--){
		scanf("%d", &qn);
		For(i, 1, qn) scanf("%d", &po[i]);
		
		if(qn==n){
			puts("0"); continue;
		}

		L = 0; R = n-1;
		while(L < R){
			mid = mxd = (L+R+1)>>1;
			
			if(Check()) L = mid;
			else R = mid-1;
		}

		printf("%d\n", L+1);
	}

	return 0;
}
