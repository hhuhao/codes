#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<vector>
#define maxn 5010
using namespace std;
int n;
int dp[maxn][maxn];
int d[maxn][maxn];
int len[200];
char ch[200][maxn];
int solve(int a,int b){
	if(len[a]<len[b])swap(a,b);
    for(int i=1;i<=len[a];i++){
        dp[i][0]=i;
    }
    for(int j=1;j<=len[b];j++){
        dp[0][j]=j;
    }
    for(int i=1;i<=len[a];i++){
        for(int j=1;j<=len[b];j++){
        	if(ch[a][i-1]==ch[b][j-1]){
				dp[i][j]=dp[i-1][j-1];
			}
        	else{
        		dp[i][j]=min(min(dp[i][j-1]+1,dp[i-1][j]+1),dp[i-1][j-1]+1);
			}
        }
    }
    return dp[len[a]-1][len[b]-1];
}
int res[10];
void file(){
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
}
int main(){
	file();
	scanf("%d",&n);
	memset(res,0,sizeof res);
	for(int i=1;i<=n;i++){
		scanf("%s",ch[i]);
		len[i]=strlen(ch[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<i;j++){
			int id=solve(i,j);
			if(id>=1 && id<=8){
				res[id]++;
			}
		}
	}
	for(int i=1;i<=8;i++){
		printf("%d ",res[i]);
	}
    return 0;
}
