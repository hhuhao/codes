#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<vector>
#define maxn 100010
using namespace std;
int n,q;
struct node{
	int v,nxt;
}e[maxn*4];
int head[maxn],cnt;
int dep[maxn],fa[maxn][25];
void add(int u,int v){
	e[cnt].v=v;
	e[cnt].nxt=head[u];
	head[u]=cnt++;
}
void dfs(int u,int p){
	for(int i=head[u];~i;i=e[i].nxt){
		if(i!=p){
			int v=e[i].v;
			dep[v]=dep[u]+1;
			fa[v][0]=u;
			dfs(v,i^1);
		}
	}
}
int lca(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	for(int i=20;i>=0;i--){
		if(dep[fa[x][i]]>=dep[y]){
			x=fa[x][i];
		}
	}
	if(x==y)return x;
	for(int i=20;i>=0;i--){
		if(fa[x][i]!=fa[y][i]){
			x=fa[x][i];
			y=fa[y][i];
		}
	}
	return fa[x][0];
} 
int kid[100010];
int vis[100010];
void file(){
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
}
int main(){
	file();
	scanf("%d%d",&n,&q);
	memset(head,-1,sizeof head);cnt=0;
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
	}
	dep[1]=1;
	dfs(1,-1);
	for(int j=1;j<=20;j++){
		for(int i=1;i<=n;i++){
			fa[i][j]=fa[fa[i][j-1]][j-1];
		} 
	}
	while(q--){
		int k;
		scanf("%d",&k);
		memset(vis,0,sizeof vis);
		for(int i=1;i<=k;i++){
			scanf("%d",&kid[i]);
			vis[kid[i]]=1;
		}
		int ans=0;
		for(int u=1;u<=n;u++){
			if(vis[u])continue;
			int res=1e8;
			for(int i=1;i<=k;i++){
				int v=kid[i];
				res=min(res,dep[u]+dep[v]-2*dep[lca(u,v)]);
			}
			ans=max(ans,res);
		}
		printf("%d\n\n",ans); 
	}
	return 0;
} 
/*
7 5
5 4
6 5
7 3
7 4
1 5
2 4
1
4
1
6
4
6 5 7 2
5
1 5 4 3 7
2
2 3

7 5
5 4
6 5
7 3
7 4
1 5
2 4
*/
