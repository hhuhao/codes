#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<vector>
#define maxn 100010
#define ll long long
#define modd 99991
using namespace std;
int n,k;
ll a[maxn];
ll f[maxn];
int vis[maxn];
int res[maxn],num;
int tmp[maxn],tp;
void dfs(int cnt,ll sum){
	if(cnt==k){
		res[++num]=sum;//printf("%d\n",sum);
		//for(int i=1;i<=tp;i++)printf("%d ",tmp[i]);cout<<endl<<endl;
		return ;
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			vis[i]=1;tmp[++tp]=a[i];
			dfs(cnt+1,sum+a[i]);
			tp--;
			vis[i]=0;
		}
	}
} 
void file(){
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
}
int main(){
	file();
	scanf("%d%d",&n,&k);num=0;
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	scanf("%lld%lld",&f[0],&f[1]);
	for(int i=2;i<=maxn-1;i++){
		f[i]=((f[i-1]*2)%modd+(f[i-2]*3)%modd)%modd;
	}
	dfs(0,0);
	ll ans=0;
	for(int i=1;i<=num;i++){
		ans=(ans+f[res[i]])%modd;//cout<<endl;
	}int kk=1;
	for(int i=2;i<=k;i++){
		kk=kk*i;
	}
	ans/=kk;
	printf("%lld\n",(ans)%modd);
	return 0;
} 
/*
20 10
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
1223 3412
*/
