#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;
const int maxn=100000+10,maxm=100000*2+10,maxk=21;
int begin[maxn],next[maxm],to[maxm],e;
inline int read(){
	char c;
	bool b=0;
	int x;
	while(((c=getchar())>'9' || c<'0') && c!='-');
	if(c=='-'){
		b=1;
		c=getchar();
	}
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	if(b) return -x;
	return x;
}
void add(int x,int y){
	to[++e]=y;
	next[e]=begin[x];
	begin[x]=e;
}
struct point{
	int x,d;
};
queue<point> q;
bool vis[maxn];
int bfs(){
	int tmp;
	while(!q.empty()){
		point u=q.front();
		tmp=u.d;
		q.pop();
		for(int i=begin[u.x];i;i=next[i])
			if(!vis[to[i]]){
				vis[to[i]]=1;
				q.push((point){to[i],u.d+1});
			}
	}
	memset(vis,0,sizeof(vis));
	return tmp;
}
int main(){
	int i,j,k,n,m;
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	n=read();
	m=read();
	for(i=1;i<n;i++){
		int x,y;
		x=read();
		y=read();
		add(x,y);
		add(y,x);
	}
	for(i=1;i<=m;i++){
		k=read();
		for(j=1;j<=k;j++){
			int u=read();
			vis[u]=1;
			q.push((point){u,0});
		}
		printf("%d\n",bfs());
	}
	return 0;
}
