#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int mod=99991,maxn=5000+10;
inline int read(){
	char c;
	bool b=0;
	int x;
	while(((c=getchar())>'9' || c<'0') && c!='-');
	if(c=='-'){
		b=1;
		c=getchar();
	}
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	if(b) return -x;
	return x;
}
int f0,f1;
int a[maxn];
long long sum=0;
struct Matrix{
	long long M[2][2];
	Matrix operator *(const Matrix &A) const{
		Matrix B;
		for(int i=0;i<=1;i++)
			for(int j=0;j<=1;j++)
				B.M[i][j]=0;
		for(int i=0;i<=1;i++)
			for(int j=0;j<=1;j++)
				for(int k=0;k<=1;k++)
//					B.M[i][j]=(B.M[i][j]+M[i][j]*A.M[j][k]%mod)%mod;
					B.M[i][j]=(B.M[i][j]+M[i][k]*A.M[k][j]%mod)%mod;
		return B;
	}
};
Matrix Bas;
long long cc(Matrix A){
	return f1*A.M[0][0]%mod+f0*A.M[0][1]%mod;
}
Matrix work(long long x){
	if(x==1) return Bas;
	Matrix tmp=work(x>>1);
	if(x&1) return tmp*tmp*Bas;
	return tmp*tmp;
}
int n;
void dfs(int x,int k,long long num){
	if(n-x+1<k) return;
	if(k==0){
		sum=(sum+cc(work(num-1)))%mod;
//		printf("%d %lld %lld\n",x,num,sum);
		return;
	}
	if(x==n+1) return;
	dfs(x+1,k-1,num+a[x]);
	dfs(x+1,k,num);
	return;
}
int main(){
	int i,j,k,m;
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	n=read();
	k=read();
	for(i=1;i<=n;i++)
		a[i]=read();
	f0=read();
	f1=read();
	Bas.M[0][0]=2;
	Bas.M[1][0]=1;
	Bas.M[0][1]=3;
	Bas.M[1][1]=0;
	dfs(1,k,0);
	printf("%lld\n",sum);
	return 0;
}
