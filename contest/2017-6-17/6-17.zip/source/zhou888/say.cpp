#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<cstdlib>
using namespace std;
const int maxn=200+10,maxlen=5000+10,inf=1e9;
inline int read(){
	char c;
	bool b=0;
	int x;
	while(((c=getchar())>'9' || c<'0') && c!='-');
	if(c=='-'){
		b=1;
		c=getchar();
	}
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	if(b) return -x;
	return x;
}
char s[maxn][maxlen];
int len[maxn];
int dp[maxlen][maxlen];
int C[10];
int main(){
	int i,j,k,n,m;
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	n=read();
	int Max=0;
	for(i=1;i<=n;i++){
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1);
		Max=max(Max,len[i]);
	}
	int l;
	for(i=1;i<=Max;i++)
		dp[i][0]=dp[0][i]=i;
	for(i=1;i<n;i++)
		for(j=i+1;j<=n;j++){
			for(k=1;k<=len[i];k++)
				for(l=1;l<=len[j];l++)
					if(s[i][k]==s[j][l])
						dp[k][l]=min(dp[k-1][l-1],min(dp[k-1][l]+1,dp[k][l-1]+1));
					else dp[k][l]=min(dp[k-1][l-1]+1,min(dp[k-1][l]+1,dp[k][l-1]+1));
			if(dp[len[i]][len[j]]<=8)
				C[dp[len[i]][len[j]]]++;
		}
	for(i=1;i<=7;i++)
		printf("%d ",C[i]);
	printf("%d\n",C[8]);
	return 0;
}
