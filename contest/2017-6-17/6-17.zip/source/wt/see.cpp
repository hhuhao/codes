#include <bits/stdc++.h>
using namespace std ;
#define LL long long
const LL maxn = 1e5+10, maxN = maxn*15, modd = 99991 ;
static char buff[maxN], *_t = buff ;
void Read ( LL &x, bool f = 0 ) {
	for ( ; !isdigit(*_t) ; ++_t ) if ( (*_t)=='-' ) f = 1 ;
	for ( x = 0 ; isdigit(*_t) ; ++_t ) x = 10*x + (*_t) - '0' ;
	if (f) x = -x ;
}
static LL n, m, K, a[maxn], ans = 0 ;
inline LL calc ( LL x ) {
	register LL bit = 1, rec = 0 ;
	for ( ; x ; x >>= 1, bit++ )
		if (x&1) rec += a[bit] ;
	return rec ;
}
struct Matrix {
	LL s[2][2], N, M ;
	friend Matrix operator * ( Matrix a, Matrix b ) {
		Matrix c ;
		c.N = a.N ;
		c.M = b.M ;
		for ( register LL i = 0 ; i < c.N ; i ++ )
			for ( register LL j = 0 ; j < c.M ; j ++ ) {
				c.s[i][j] = 0 ;
				for ( LL k = 0 ; k < a.M ; k ++ )
					( c.s[i][j] += a.s[i][k]*b.s[k][j] ) %= modd ;
			}
		return c ;
	}
} A, B ;
inline Matrix qpow ( Matrix b, LL t ) {
	Matrix c = b ;
	for ( --t ; t ; t >>= 1, b = b*b )
		if (t&1) c = c*b ;
	return c ;
}
LL F ( LL x ) {
	Matrix c ;
	c = qpow(B,x-1) ;
	return ( A.s[0][0]*c.s[0][1] + A.s[0][1]*c.s[1][1] ) %modd ;
}
static int sum = 0 ;
void dfs ( int stp, int tot ) {
	if ( tot+n-stp+1 < K ) return ;
	if ( tot == K ) {
		ans = ( ans + F(sum) )%modd ;
		return ;
	}
	if ( stp > n ) return ;
	sum += a[stp] ;
	dfs(stp+1,tot+1) ;
	sum -= a[stp] ;
	dfs(stp+1,tot) ;
}
int main() {
	freopen ( "see.in", "r", stdin ) ;
	freopen ( "see.out", "w", stdout ) ;
	fread ( buff, 1, maxN, stdin ) ;
	register LL i, j, x ;
	A.N = 1 ; A.M = 2 ;
	B.N = B.M = 2 ;
	B.s[0][0] = 0 ;
	B.s[0][1] = 3 ;
	B.s[1][0] = 1 ;
	B.s[1][1] = 2 ;
	Read(n) ; Read(K) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(a[i]) ;
	Read(A.s[0][0]) ; Read(A.s[0][1]) ;
	dfs(1,0) ;
	printf ( "%lld\n", ans ) ;
	return 0 ;
}
