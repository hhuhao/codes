#include <bits/stdc++.h>
using namespace std ;
const int maxn = 1e5+10, maxN = maxn*150, maxm = maxn<<1 ;
char buff[maxN], *_t = buff ;
void Read ( int &x, bool f = 0 ) {
	for ( ; !isdigit(*_t) ; ++_t ) if ( (*_t)=='-' ) f = 1 ;
	for ( x = 0 ; isdigit(*_t) ; ++_t ) x = 10*x + (*_t) - '0' ;
	if (f) x = -x ;
}
int n, m, size[maxn], dep[maxn], fa[maxn], top[maxn], dfn[maxn], son[maxn], cnt ;
int e, be[maxn], nxt[maxn<<1], to[maxn<<1], tree[maxn<<2], id[maxn], clk, deg[maxn] ;

void init() {
	memset ( fa, -1, sizeof(fa) ) ;
	memset ( son, -1, sizeof(son) ) ;
}

void add ( int x, int y ) {
	to[++e] = y ;
	nxt[e] = be[x] ;
	be[x] = e ;
}

int dfs1 ( int x, int father, int deep ) {
	fa[x] = father ;
	dep[x] = deep ;
	size[x] = 1 ;
	int i, u ;
	for ( i = be[x] ; i ; i = nxt[i] ) {
		u = to[i] ;
		if ( u == father ) continue ;
		size[x] += dfs1 ( u, x, deep+1 ) ;
		if ( son[x] == -1 || size[u] > size[son[x]] ) son[x] = u ;
	}
	return size[x] ;
}

void dfs2 ( int x, int Top ) {
	top[x] = Top ;
	dfn[x] = ++cnt ;
	int i, u ;
	if ( son[x] ) {
		for ( i = be[x] ; i ; i = nxt[i] ) {
			u = to[i] ;
			if ( u == son[x] ) dfs2 ( u, Top ) ;
		}
	} else return ;
	for ( i = be[x] ; i ; i = nxt[i] ) {
		u = to[i] ;
		if ( u == fa[x] || u == son[x] ) continue ;
		dfs2 ( u, u ) ;
	}
}

void push_up ( int h ) { tree[h] = tree[h<<1]+tree[h<<1|1] ; }
void create ( int h, int l, int r ) {
	if ( l == r ) {
		tree[h] = 1 ;
		return ;
	}
	int mid = l+r>>1 ;
	create ( h<<1, l, mid ) ;
	create ( h<<1|1, mid+1, r ) ;
	push_up(h) ;
}

int query ( int h, int l, int r, int x, int y ) {
	if ( x <= l && r <= y ) return tree[h] ;
	int mid = l+r >> 1 ;
	if ( y <= mid ) return query ( h<<1, l, mid, x, y ) ;
	else if ( x > mid ) return query ( h<<1|1, mid+1, r, x, y ) ;
	else return query ( h<<1, l, mid, x, mid ) + query ( h<<1|1, mid+1, r, mid+1, y ) ;
}

int Query ( int u, int v ) {
	int rec = 0 ;
	while ( top[u] != top[v] ) {
		if ( dep[top[u]] > dep[top[v]] ) swap ( u, v ) ;
		rec += query ( 1, 2, n, dfn[top[v]], dfn[v] ) ;
		v = fa[top[v]] ;
	}
	if ( u != v ) {
		if ( dep[u] > dep[v] ) swap ( u, v ) ;
		rec += query ( 1, 2, n, dfn[u]+1, dfn[v] ) ;
	}
	return rec ;
}
void dfs ( int x ) {
	id[x] = ++clk ;
	for ( int i = be[x] ; i ; i = nxt[i] )
		if ( !id[to[i]] ) dfs(to[i]) ;
}
int a[maxn] ;
int main() {
	freopen ( "do.in", "r", stdin ) ;
	freopen ( "do.out", "w", stdout ) ;
	fread ( buff, 1, maxN, stdin ) ;
	int i, j, k, x, y, z, _, ans, rec ;
	Read(n) ; Read(_) ;
	for ( i = 1 ; i < n ; i ++ ) {
		Read(x) ; Read(y) ;
		add ( x, y ) ;
		add ( y, x ) ;
		++deg[x] ;
		++deg[y] ;
	}
	if ( n <= 3000 ) {
		dfs1(1,1,1) ;
		dfs2(1,1) ;
		create(1,2,n) ;
		while ( _-- ) {
			Read(m) ;
			for ( i = 1 ; i <= m ; i ++ ) Read(a[i]) ;
			for ( ans = -1, i = 1 ; i <= n ; i ++ ) {
				rec = 0x3f3f3f3f ;
				for ( j = 1 ; j <= m ; j ++ )
					rec = min( rec, Query(i,a[j]) ) ;
				ans = max( ans, rec ) ;
			}
			printf ( "%d\n", ans ) ;
		}
		return 0 ;
	} else {
		for ( i = 1 ; i <= n ; i ++ )
			if ( deg[i]==1 )
				break ;
		dfs(i) ;
		while ( _-- ) {
			Read(k) ;
			for ( i = 1 ; i <= k ; i ++ ) {
				Read(x) ;
				a[i] = id[x] ;
			}
			sort(a+1, a+k+1) ;
			ans = max( a[1]-1, k-a[k] ) ;
			for ( i = 1 ; i < n ; i ++ )
				ans = max( a[i+1]-a[i]>>1, ans ) ;
			printf ( "%d\n", ans ) ;
		}
		return 0 ;
	}
	return 0 ;
}
