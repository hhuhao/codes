#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<cstring>
#include<map>
#include<iostream>
using namespace std;
const int maxn=210;
int dp[6010][6010];
int n;
char s[maxn][13000];
int ans[10];
int len[maxn];
void solve(int x,int y){
	int la=len[x],lb=len[y];
	if(abs(la-lb)>8) return;
	for(int i=1;i<=la;i++){
		for(int j=1;j<=lb;j++){
			if(s[x][i]==s[y][j]) dp[i][j]=dp[i-1][j-1];
			else dp[i][j]=dp[i-1][j-1]+1;
			dp[i][j]=min(dp[i][j],min(dp[i-1][j]+1,dp[i][j-1]+1));
		}
	}
	if(dp[la][lb]<=8) ans[dp[la][lb]]++;
}
int Max;
int main(){
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%s",s[i]+1),len[i]=strlen(s[i]+1),Max=max(Max,len[i]);
	dp[0][0]=0;
	for(int i=1;i<=Max;i++) dp[i][0]=dp[0][i]=i;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++) solve(i,j);
	for(int i=1;i<=8;i++) printf("%d ",ans[i]);
	return 0;
}
