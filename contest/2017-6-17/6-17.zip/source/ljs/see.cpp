#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<iostream>
using namespace std;
const int maxn=1000010;
const int mod=99991;
typedef long long LL;
int n,k;
LL a[maxn];
LL f[maxn];
void init(){
	for(int i=2;i<maxn;i++) f[i]=(f[i-1]*2+f[i-2]*3)%mod;
}
LL ans;
struct Matrix{
	LL a[2][2];
	void clear(){
		memset(a,0,sizeof(a));
	}
	Matrix operator *(const Matrix& A)const{
		Matrix ret;
		ret.clear();
		for(int k=0;k<2;k++){
			for(int i=0;i<2;i++){
				for(int j=0;j<2;j++){
					ret.a[i][j]=(ret.a[i][j]+a[i][k]*A.a[k][j])%mod;
				}
			}
		}
		return ret;
	}
}Ans,t;
void Pow(LL y){
	t.clear();t.a[0][0]=2;t.a[0][1]=3;t.a[1][0]=1;t.a[1][1]=0;
	while(y){
		if(y&1LL) Ans=t*Ans;
		t=t*t;
		y>>=1;
	}
	//cerr<<Ans.a[0][0];
}
void solve(LL x){
	Ans.clear();
	Ans.a[0][0]=f[1];Ans.a[1][0]=f[0];
	Pow(x-1);
	//printf("%lld %lld %lld\n",x,f[x],Ans.a[0][0]);
	ans=(ans+Ans.a[0][0])%mod;
}
LL Sum;
int dp[2][110][10010];
void solve1(){
	dp[0][0][0]=1;
	for(int l=1;l<=n;l++){
		int now=l&1;
		for(int i=0;i<=k;i++) for(int j=0;j<=Sum;j++) dp[now][i][j]=0;
		for(int i=0;i<=min(l,k);i++){
			for(int j=0;j<=Sum;j++){
				dp[now][i][j]=dp[now^1][i][j];
				if(j>=a[l] && i>=1){dp[now][i][j]=(dp[now][i][j]+dp[now^1][i-1][j-a[l]])%mod;}
			}
		}
	}
	for(int i=1;i<=Sum;i++){
		ans=(ans+f[i]*dp[n&1][k][i]%mod)%mod;
	}
	printf("%lld",ans);
}
int main(){
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]),Sum+=a[i];
	scanf("%lld%lld",&f[0],&f[1]);
	init();
	if(n<=100 && Sum<=10000){
		solve1();
		return 0;
	}
	for(int i=1;i<(1<<n);i++){
		int cnt=0;LL sum=0;
		for(int j=1;j<=n;j++){
			if(i & (1<<(j-1))) cnt++,sum+=a[j];
		}
		if(cnt!=k) continue;
		if(sum<maxn) ans=(ans+f[sum])%mod;
		else solve(sum);
	}
	printf("%lld",ans);
	return 0;
}
