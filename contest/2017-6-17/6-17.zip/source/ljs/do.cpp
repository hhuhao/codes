#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=3010;
const int INF=1e9;
int n,q,k;
int to[maxn*2],Next[maxn*2],Begin[maxn],e;
int t[maxn];
int fa[maxn][20];
void read(int& x){
	x=0;
	char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
}
void add(int x,int y){
	to[++e]=y;
	Next[e]=Begin[x];
	Begin[x]=e;
}
int dep[maxn];
int d[maxn][maxn];
int f[maxn];
void dfs(int x){
	for(int i=Begin[x];i;i=Next[i]){
		int v=to[i];
		if(v==fa[x][0]) continue;
		fa[v][0]=x;
		dep[v]=dep[x]+1;
		dfs(v);
	}
}
int LCA(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	int h=dep[x]-dep[y];
	for(int i=18;i>=0;i--) if(h & (1<<i)) x=fa[x][i];
	if(x==y) return x;
	for(int i=18;i>=0;i--) if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
	if(x==y) return x;
	return fa[x][0];
}
int dis(int x,int y){
	int lca=LCA(x,y);
	return dep[x]+dep[y]-2*dep[lca];
}
int main(){
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	read(n);read(q);
	int u,v;
	for(int i=1;i<n;i++){
		read(u);read(v);
		add(u,v);add(v,u);
	}
	dep[1]=1;
	dfs(1);
	for(int j=1;j<=18;j++)
		for(int i=1;i<=n;i++) fa[i][j]=fa[fa[i][j-1]][j-1];
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++) d[i][j]=d[j][i]=dis(i,j);
	while(q--){
		for(int i=1;i<=n;i++) f[i]=INF;
		read(k);
		for(int i=1;i<=k;i++) read(t[i]);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=k;j++){
				if(i==t[j]){ f[i]=0;break; }
				f[i]=min(f[i],d[i][t[j]]);
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++) ans=max(ans,f[i]);
		printf("%d\n",ans);
	}
	return 0;
}
