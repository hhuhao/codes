#include<cstdio>
#include<iostream>
#define For(aa,bb,cc) for(int aa=(bb);aa<=(int)(cc);++aa)
using namespace std;
typedef long long LL;
const int maxn=1e5+10,mod=99991;
int n,k;
int a[maxn];
LL f[110],Ans=0;
struct matrix{ LL m[22][22]; }C,D,E,I;
struct queue{ int id,num; }q[maxn];

template<class T>
void read(T &x){
	x=0;char c=getchar();int fuhao=0;
	while(!isdigit(c)) fuhao|=c=='-',c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	if(fuhao) x=-x;
}

matrix operator *(matrix A,matrix B){
	matrix ans;
	For(i,1,3) For(j,1,3) ans.m[i][j]=0;
	For(i,1,3)
		For(j,1,3)
			For(l,1,3)
				ans.m[i][j]=(A.m[i][l]*B.m[l][j]%mod+ans.m[i][j])%mod;
	return ans;
}

matrix operator ^(matrix A,LL x){
	matrix ans=I;
	while(x){
		if(x&1) ans=ans*A;
		A=A*A;
		x>>=1;
	}
	return ans;
}

void dfs(int pos,int cnt){
	if(n-pos+1<k-cnt) return ;
	if(cnt==k){
		LL sum=0;
		For(i,1,cnt) sum+=q[i].num;
		Ans=(Ans+f[sum])%mod;
		return ;
	}
	if(cnt>k || pos>n) return ;
	For(i,q[cnt].id+1,n){
		q[cnt+1]=(queue){i,a[i]};
		dfs(i+1,cnt+1);
	}
}

void print(matrix res){
	For(i,1,3){
		For(j,1,3){
			cerr<<res.m[i][j]<<" ";
		}
		cerr<<endl;
	}
	cerr<<endl;
}

int main(){
#ifndef ONLILNE_JUDGE
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
#endif
	read(n),read(k);
	For(i,1,n) read(a[i]);
	read(f[0]),read(f[1]);
	f[0]%=mod,f[1]%=mod;
	/*For(i,1,3) I.m[i][i]=1;
	C.m[1][1]=f[0],C.m[2][1]=f[1],C.m[3][1]=f[2];
	D.m[1][2]=1,D.m[2][3]=1,D.m[3][2]=2,D.m[3][3]=3;*/
	For(i,2,100000) f[i]=(f[i-1]*2%mod+f[i-2]*3%mod)%mod;
	dfs(1,0);
	printf("%lld\n",Ans%mod);
	return 0;
}
