#include<cstdio>
#include<iostream>
#define For(aa,bb,cc) for(int aa=(bb);aa<=(cc);++aa)
using namespace std;

int main(){
#ifndef ONLINE_JUDGE
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
#endif
	return 0;
}
