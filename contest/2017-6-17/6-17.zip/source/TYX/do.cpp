#include<cstdio>
#include<cstring>
#include<iostream>
#define For(aa,bb,cc) for(int aa=(bb);aa<=(int)(cc);++aa)
using namespace std;
const int inf=0x3f3f3f3f,maxn=1e5+10;
int n,q;
int be[maxn],ne[maxn<<1],to[maxn<<1],e;

template<class T>
void read(T &x){
	x=0;char c=getchar();int fuhao=0;
	while(!isdigit(c)) fuhao|=c=='-',c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	if(fuhao) x=-x;
}

inline void add_edge(int x,int y){
	to[++e]=y,ne[e]=be[x],be[x]=e;
	to[++e]=x,ne[e]=be[y],be[y]=e;
}

namespace Force{
	const int maxm=3010;
	int dis[maxm][maxm],p[maxm];
	bool vis[maxm];


	void dfs(int node,int pre,int d){
		vis[node]=1;
		dis[pre][node]=d;
		for(int i=be[node];i;i=ne[i]){
			int u=to[i];
			if(vis[u]) continue;
			dfs(u,pre,d+1);
		}
		vis[node]=0;
	}

	void solve(){
		int x,y,tmp,ans;
		For(i,1,n-1) read(x),read(y),add_edge(x,y);
		For(i,1,n) dfs(i,i,0);
		while(q--){
			read(x);
			ans=0;
			For(i,1,x) read(p[i]),vis[p[i]]=1;
			For(i,1,n){
				if(vis[i]){
					vis[i]=0;
					continue;
				}
				tmp=inf;
				For(j,1,x)
					tmp=min(dis[i][p[j]],tmp);
				ans=max(tmp,ans);
			}
			printf("%d\n",ans);
		}
	}
}

namespace LCA{
	int top[maxn],dep[maxn],son[maxn],fa[maxn],size[maxn];
	int p[maxn];
	bool vis[maxn];

	void dfs1(int node,int f,int d){
		fa[node]=f;
		dep[node]=d;
		size[node]=1;
		for(int i=be[node];i;i=ne[i]){
			int u=to[i];
			if(u==f) continue;
			dfs1(u,node,d+1);
			size[node]+=size[u];
			if(son[node]==-1 || size[son[node]]<size[u]) son[node]=u;
		}
	}

	void dfs2(int node,int f){
		top[node]=f;
		if(son[node]==-1) return ;
		dfs2(son[node],f);
		for(int i=be[node];i;i=ne[i]){
			int u=to[i];
			if(u==fa[node] || u==son[node]) continue;
			dfs2(u,u);
		}
	}

	int ask_lca(int x,int y){
		while(top[x]!=top[y]){
			if(dep[top[x]]<dep[top[y]]) swap(x,y);
			x=fa[top[x]];
		}
		return dep[x]>dep[y]?y:x;
	}

	void solve(){
		int x,y,tmp,ans;
		memset(son,-1,sizeof son);
		For(i,1,n-1) read(x),read(y),add_edge(x,y);
		dfs1(1,1,0);
		dfs2(1,1);
		while(q--){
			read(x);ans=0;
			For(i,1,x) read(p[i]),vis[p[i]]=1;
			For(i,1,n)
				if(vis[i]) vis[i]=0;
				else{
					tmp=inf;
					For(j,1,x){
						tmp=min(tmp,dep[i]+dep[p[j]]-2*dep[ask_lca(i,p[j])]);
					}
					ans=max(tmp,ans);
				}
			printf("%d\n",ans);
		}
	}
}

int main(){
#ifndef ONLINE_JUDGE
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
#endif
	read(n),read(q);
	if(n<=3000) Force::solve();
	else LCA::solve();
}
