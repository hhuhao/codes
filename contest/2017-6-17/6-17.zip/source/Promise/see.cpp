#include<cstdio>
#include<cstdlib>
#include<iostream>

#define For(a, b, c) for(a = b; a <= (int)(c); ++a)
using namespace std;
const int mod = 99991;
int n, k;
long long m[2][2] = {{2, 3}, {1, 0}}, c[2][2], d[2][2], ans, sum, a[100005], f[2];

inline void pow_matrix(long long kk){
	if(kk <= 1){
		(ans += f[kk]) %= mod;
		return ;
	}
	int i, j, k;
	long long fin[2][2];
	For(i, 0, 1) For(j, 0, 1) c[i][j] = fin[i][j] = m[i][j];
	--kk;
	--kk;
	while(kk){
		if(kk % 2){
			--kk;
			d[0][0] = d[0][1] = d[1][0] = d[1][1] = 0;
			For(i, 0, 1) For(j, 0, 1) For(k, 0, 1)
				(d[i][j] += fin[i][k] * c[k][j]) %= mod;
			For(i, 0, 1) For(j, 0, 1) fin[i][j] = d[i][j];
			if(!kk) break;
		}
		d[0][0] = d[0][1] = d[1][0] = d[1][1] = 0;
		For(i, 0, 1) For(j, 0, 1) For(k, 0, 1)
			(d[i][j] += c[i][k] * c[k][j]) %= mod;
		For(i, 0, 1) For(j, 0, 1) c[i][j] = d[i][j];
		kk >>= 1;
	}
	(ans += (fin[0][0] * f[1] + fin[0][1] * f[0]) % mod) %= mod;
}

void dfs(int x, int d){
	if(d == k){
		pow_matrix(sum);
		return ;
	}
	int i;
	For(i, x, n - k + d + 1){
		sum += a[i];
		dfs(i + 1, d + 1);
		sum -= a[i];
	}
}

int main(){
	freopen("see.in", "r", stdin);
	freopen("see.out","w",stdout);
	int i;
	scanf("%d%d", &n, &k);
	For(i, 1, n) scanf("%lld", &a[i]);
	scanf("%lld%lld", &f[0], &f[1]);
	dfs(1, 0);
	printf("%lld", ans);
	return 0;
}
