#include<cstdio>
#include<iostream>
#include<algorithm>

#define maxn 100005
#define For(a, b, c) for(a = b; a <= (int)(c); ++a)

using namespace std;
int n, q, qq[maxn], dis[maxn], last[maxn], bf[maxn], link[maxn];
int e, be[maxn], to[maxn << 1], ne[maxn << 1];
bool p[maxn];

inline void add(int x, int y){
	to[++e] = y;
	ne[e] = be[x];
	be[x] = e;
}

inline void bfs(int x, int t){
	int i, v, f = 0, l = 1;
	bf[1] = x, dis[x] = 0;
	while(f++ < l){
		for(i = be[bf[f]]; i; i = ne[i]){
			v = to[i];
			if((last[v] == t && dis[v] <= dis[bf[f]] + 1) || p[v]) continue;
			last[v] = t;
			dis[v] = dis[bf[f]] + 1;
			bf[++l] = v;
		}
	}
}

inline void solve1(){
	int i, k;
	while(q--){
		scanf("%d", &k);
		For(i, 1, k) scanf("%d", &qq[i]);
		sort(qq + 1, qq + k + 1);
		int ans = max(qq[1] - 1, n - qq[k]);
		For(i, 2, k) if(((qq[i] - qq[i - 1]) >> 1) > ans) ans = (qq[i] - qq[i - 1]) >> 1;
		printf("%d\n", ans);
	}
}

int main(){
	freopen("do.in", "r", stdin);
	freopen("do.out","w",stdout);
	int i, k, u, v;
	bool pp = 1;
	scanf("%d%d", &n, &q);
	For(i, 2, n){
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
		if(pp){
			++link[u], ++link[v];
			if(link[u] > 2 || link[v] > 2) pp = 0;
		}
	}
	if(pp){
		solve1();
		return 0;
	}
	For(u, 1, q){
		int ans = 0;
		scanf("%d", &k);
		For(i, 1, k) scanf("%d", &qq[i]), p[qq[i]] = 1;
		For(i, 1, k) bfs(qq[i], u);
		For(i, 1, k) p[qq[i]] = 0;
		For(i, 1, n) if(dis[i] > ans) ans = dis[i];
		printf("%d\n", ans);
	}
	return 0;
}
