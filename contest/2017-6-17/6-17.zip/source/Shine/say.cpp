#include<cstdio>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

const int MAXN = 210, MAXL = 5010;
const int INF = 1000000000;
int n, l[MAXN], ans[MAXN];
char s[MAXN][MAXL];

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x<<1)+(x<<3)+(ch^48);
	return x * f;
}

int dfs(int i, int j, int p1, int p2, int k) {
	//if(i == 3 && j == 4) printf("%d %d %d %c %c\n", p1, p2, k, s[i][p1], s[j][p2]);
	//printf("{\n");
	if(p1 == l[i] && p2 == l[j]) {
		//printf("}\n");
		return k;
	}
	if(s[i][p1] == s[j][p2]) {
		int v = dfs(i, j, p1+1, p2+1, k);
		//printf("}\n");
		return v;
	}
	if(k >= 8) {
		//printf("}\n");
		return INF;
	}
	int v = INF;
	if(p1 < l[i]) v = min(v, dfs(i, j, p1+1, p2, k+1));
	if(p2 < l[j]) v = min(v, dfs(i, j, p1, p2+1, k+1));
	if(p1 < l[i] && p2 < l[j])v = min(v, dfs(i, j, p1+1, p2+1, k+1));
	//printf("}\n");
	return v;
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("say.in", "r", stdin);
	freopen("say.out", "w", stdout);
#endif
	int i, j;
	n = read();
	for(i = 1; i <= n; i++) {
		scanf("%s", s[i]);
		l[i] = strlen(s[i]);
		//printf("%s\n", s[i]);
	}
	//printf("%c\n", s[1][13]);
	//ans[dfs(3, 4, 0, 0, 0)]++;
	for(i = 1; i <= n; i++) 
		for(j = i+1; j <= n; j++) {
			int v = dfs(i, j, 0, 0, 0);
			//if(v == 7) printf("%d %d\n", i, j);
			if(v != INF) ans[v]++;
		}
	for(i = 1; i <= 8; i++) printf("%d ", ans[i]);
	printf("\n");
	return 0;
}
