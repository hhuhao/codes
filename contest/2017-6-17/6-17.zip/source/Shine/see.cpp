#include<cstdio>
#include<cmath>
#include<algorithm>
#include<vector>
#include<iostream>
using namespace std;

typedef long long ll;
const int MAXN = 50;
const ll MOD = 99991;
int n, k, a[MAXN];
ll f0, f1, ans;
ll c1, c2;
vector<int> v;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x<<1)+(x<<3)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b&1LL) res = res * a % MOD;
		a = a * a % MOD;
		b >>= 1;
	}
	return res;
}

inline ll f(ll x) {
	//printf("%.3lf\n", qpow(3, x));
	ll res = (qpow(3, x)*c1%MOD+((x&1LL)?(-1):1)*c2%MOD+MOD)%MOD;
	res = res * qpow(4, MOD-2) % MOD;
	return res;
}

void dfs(int u, int s, ll sum) {
	if(s == k) {
		//printf("%lld\n", sum);
		ans = (ans+f(sum))%MOD;
		//printf("%lld\n", ans);
		/*for(int i = 0; i < (int)v.size(); i++) {
			printf("%d ", v[i]);
		}*/
		////printf("\n");
		return;
	}
	if(u == n+1) return;
	//v.push_back(u);
	dfs(u+1, s+1, sum+a[u]);
	//v.resize(v.size()-1);
	dfs(u+1, s, sum);
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("see.in", "r", stdin);
	freopen("see.out", "w", stdout);
#endif
	int i;
	n = read(), k = read();
	for(i = 1; i <= n; i++) a[i] = read();
	f0 = read(), f1 = read();
	c1 = f0+f1;
	c2 = 3*f0-f1;
	//printf("%.3lf %.3lf\n", c1, c2);
	/*printf("%lld\n%lld\n", f0, f1);
	for(i = 2; i <= MOD; i++) {
		ll t = (2*f1+3*f0)%MOD;
		printf("%lld\n", t);
		f0 = f1, f1 = t;
	}*/
	//for(i = 0; i <= MOD; i++) printf("%lld\n", f(i));
	dfs(1, 0, 0);
	printf("%lld\n", ans);
	return 0;
}
