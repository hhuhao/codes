#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;

const int MAXN = 100010;
const int INF = 1000000000;
int n, q, e, k, to[MAXN<<1];
int Begin[MAXN], Next[MAXN<<1];
int f[MAXN], ans, head, tail;
int que[MAXN], deg[MAXN], p[MAXN];
int dfn[MAXN], dfs_clock;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x<<1)+(x<<3)+(ch^48);
	return x * f;
}

inline void Add(int u, int v) {
	to[++e] = v, Next[e] = Begin[u];
	Begin[u] = e;
}

inline void BFS() {
	while(head < tail) {
		int u = que[++head], i;
		for(i = Begin[u]; i; i = Next[i]) {
			int v = to[i];
			if(f[v] != INF) continue;
			f[v] = f[u]+1;
			que[++tail] = v;
		}
	}
}

void dfs(int u, int fa) {
	dfn[u] = ++dfs_clock;
	int i;
	for(i = Begin[u]; i; i = Next[i]) {
		if(to[i] == fa) continue;
		dfs(to[i], u);
	}
}

bool cmp(int a, int b) {
	return dfn[a] < dfn[b];
}

inline void Line() {
	int r, i;
	for(r = 1; r <= n; r++) if(deg[r] == 1) break;
	dfs(r, 0);
	while(q--) {
		k = read();
		for(i = 1; i <= k; i++) p[i] = read();
		sort(p+1, p+k+1, cmp);
		int ans = dfn[1]-1;
		for(i = 2; i <= k; i++) ans = max(ans, dfn[i]-dfn[i-1]);
		printf("%d\n", ans/2);
	}
	exit(0);
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("do.in", "r", stdin);
	freopen("bf.out", "w", stdout);
#endif
	n = read(), q = read();
	int i;
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
		deg[u]++, deg[v]++;
	}
	//for(i = 1; i <= n; i++) if(deg[i] > 2) break;
	//if(i > n) Line();
	while(q--) {
		k = read();
		if(k == 0) continue;
		head = tail = ans = 0;
		for(i = 1; i <= n; i++) f[i] = INF;
		for(i = 1; i <= k; i++) f[que[++tail] = read()] = 0;
		BFS();
		for(i = 1; i <= n; i++) ans = max(ans, f[i]);
		printf("%d\n", ans);
	}
	return 0;
}
