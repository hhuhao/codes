#include<cstdio>
#include<iostream>
#include<ctime>
#include<algorithm>
using namespace std;

const int MAXN = 100010;
int p[MAXN], n, q;

int main() {
	freopen("do.in", "w", stdout);
	int i, j;
	srand(time(0));
	cerr << rand() << endl;
	n = rand()%5000+5000, q = 5000;
	printf("%d %d\n", n, q);
	for(i = 1; i <= n; i++) p[i] = i;
	for(i = 2; i <= n; i++) {
		int u = rand()%(i-1)+1;
		swap(p[i], p[u]);
	}
	for(i = 1; i < n; i++) printf("%d %d\n", p[i], p[i+1]);
	for(i = 1; i < q; i++) {
		p[i] = rand()%n+1;
		rand();
		rand();
	}
	p[q] = n;
	sort(p+1, p+q+1);
	p[0] = 0;
	for(j = 1; j <= q; j++) {
		int k = p[j]-p[j-1];
		printf("%d\n", k);
		for(i = p[j-1]+1; i <= p[j]; i++) printf("%d ", i);
		printf("\n");
	}
	return 0;
}
