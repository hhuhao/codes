#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=12000;

int n;
char s[209][N];
int len[209],dp[2][N];
int ans[9];

inline int minn(int a,int b){if(a<b)return a;return b;}

inline void mian(int x,int y)
{
	if(len[x]<len[y])swap(x,y);

	int lenx=len[x],leny=len[y];
	memset(dp,0x3f3f3f3f,sizeof(dp));

	for(int i=0;i<=leny;i++)
		dp[0][i]=i;

	//printf("\n\n%d %d:\n",x,y);
	int f=1;
	for(int i=1;i<=lenx;i++,f^=1)
	{
		dp[f][0]=i;

		for(int j=1,inc=(s[x][i]!=s[y][j]);j<=leny;j++,inc=(s[x][i]!=s[y][j]))
			dp[f][j]=minn(dp[f^1][j-1]+inc,minn(dp[f][j-1]+1,dp[f^1][j]+1));
	/*	
		printf("%d:",i);
		for(int j=1;j<=leny;j++)
			printf("%d ",dp[f][j]);
		puts("");
	*/
	}
	
	if(dp[f^1][leny]<=8)
		ans[dp[f^1][leny]]++;
}

int main()
{
	if(fopen("say.in","r")!=NULL)
	{
		freopen("say.in","r",stdin);
		freopen("say.out","w",stdout);
	}

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1);
	}

	for(int i=1;i<n;i++)
		for(int j=i+1;j<=n;j++)
			mian(i,j);

	for(int i=1;i<=7;i++)
		printf("%d ",ans[i]);
	printf("%d\n",ans[8]);

	return 0;
}

