#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=100009;

int n,q;
int efa[N],eto[N<<1],enxt[N<<1],ebeg[N],etot;
int fa[N];

int st[N<<1][20],id[N],dfs_clock;

int dep[N],dson[N],siz[N];

int sid[N<<1],rid[N],stop,stk[N],top,ans;
bool mrk[N],isfa[N],isson[N];

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9'){x=x*10+(ch^48);ch=getchar();}
	return x;
}

inline int maxx(int a,int b){if(a>b)return a;return b;}
inline int minn(int a,int b){if(a<b)return a;return b;}

inline void eadd(int u,int v)
{
	eto[++etot]=v;
	enxt[etot]=ebeg[u];
	ebeg[u]=etot;
}

inline void mdfs(int u)
{
	dson[u]=u;
	id[st[++dfs_clock][0]=u]=dfs_clock;

	for(int i=ebeg[u],v;i;i=enxt[i])
		if((v=eto[i])!=efa[u])
		{
			dep[v]=dep[u]+1;
			efa[v]=u;

			mdfs(v);
			
			if(dep[dson[v]]>dep[dson[u]])
				dson[u]=dson[v];
			st[++dfs_clock][0]=u;
		}
}

inline void rmq()
{
	for(int i=1;(1<<i)<=20;i++)
		for(int j=1;j+(1<<i)<=dfs_clock;j++)
		{
			if(dep[st[j][i-1]]<dep[st[j+(1<<i-1)][i-1]])
				st[j][i]=st[j][i-1];
			else
				st[j][i]=st[j+(1<<i-1)][i-1];
		}
}

inline int lca(int x,int y)
{
	if(x==y)
		return x;

	x=id[x];
	y=id[y];
	if(x>y)
		swap(x,y);

	//printf("q lca %d %d\n",x,y);
	int len=0;
	while((1<<len)<y-x+1)len++;
	//printf("len %d\n",len);

	if(dep[st[x][len-1]]<dep[st[y-(1<<len-1)+1][len-1]])
		return st[x][len-1];
	return st[y-(1<<len-1)+1][len-1];
}

void ndfs(int u)
{
	if(mrk[u])
	{
		siz[u]=1;
		if(top)
		{
			ans=maxx(ans,dep[u]-dep[stk[top]]);
			fa[u]=stk[top];
			isfa[stk[top]]=1;
			isson[u]=1;
			//printf("fa %d=%d\n",u,stk[top]);
		}

		rid[sid[++stop]=u]=stop;
		stk[++top]=u;
	}
	else
		siz[u]=0;
	
	for(int i=ebeg[u],v;i;i=enxt[i])
		if((v=eto[i])!=efa[u])
		{
			ndfs(v);
			siz[u]+=siz[v];
		}

	if(mrk[u])
	{
		top--;
		sid[++stop]=u;
		//printf("sons %d:\n",u);
		for(int i=ebeg[u],v;i;i=enxt[i])
			if((v=eto[i])!=efa[u] && !siz[v])
			{
				//printf("siz %d:%d\n",v,siz[v]);
				ans=maxx(ans,(dep[dson[v]]-dep[u])<<1);
				//printf("%d:%d\n",dson[v],ans);
			}
	}
}

void dfs(int u,int x)
{
	//printf("now %d\n",u);
	for(int i=ebeg[u],v;i;i=enxt[i])
	{
		if((v=eto[i])!=efa[u] && !siz[v])
		{
			//printf("upd %d\n",v);
			ans=maxx(ans,(dep[x]+dep[dson[v]]-(dep[u]<<1))*2);
		}
	}

	if(efa[u]>=1)
	{
		u=efa[u];
		dfs(u,x);
	}
}

int main()
{
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);

	n=read();
	q=read();

	for(int i=1,u,v;i<n;i++)
	{
		u=read();
		v=read();
		eadd(u,v);
		eadd(v,u);
	}

	mdfs(1);
	rmq();

	for(int i=1,k;i<=q;i++)
	{
		//printf("\n\n\nq %d\n",i);
		for(int j=1;j<=n;j++)
		{
			mrk[j]=0;
			isfa[j]=0;
			isson[j]=0;
			fa[j]=0;
		}

		k=read();
		for(int i=1;i<=k;i++)
			mrk[read()]=1;

		ans=-1;
		top=stop=0;

		ndfs(1);

		//puts("nyg");
		for(int j=1;j<=stop;j++)
		{
			if(rid[sid[j]]==j)
				continue;

			//printf("in %d\n",sid[j]);
			int x=sid[j];
			for(int k=j+1;k<=stop;k++)
			{
				if(sid[k]==sid[k-1])continue;
				int lcaa=lca(x,sid[k]);
				if(lcaa==fa[x])
					continue;
	
				//printf("lca %d %d\n",x,sid[k]);
				
				ans=maxx(ans,minn(dep[x]+dep[sid[k]]-(dep[lcaa]<<1)
							,minn(dep[x],dep[sid[k]])-dep[fa[x]]));

				if(dep[x]<dep[sid[k]])
					isson[sid[k]]=1;
				else isson[x]=1;
			}

			if(!isfa[x])
			{
				//printf("leaf %d\n",x);
				ans=maxx(ans,((dep[dson[x]]-dep[x])<<1));
			}
			if(!isson[x])
			{
				//printf("root %d\n",x);
				if(efa[x]>=0)
					dfs(efa[x],x);
			}
		}

		printf("%d\n",ans>>1);
	}
	
	return 0;
}
/*
7 5
5 4
6 5
7 3
7 4
1 5
2 4
1
4
1
6
4
6 5 7 2
5
1 5 4 3 7
2
2 3

*/
