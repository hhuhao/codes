#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef long long ll;

const int N=100009;
const int md=99991;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9'){x=x*10+(ch^48);ch=getchar();}
	return x*f;
}

int n,k;
int a[N],f0,f1;
ll sum,ans;
int siz[md+9];

inline ll calc(ll x)
{
	ll fl2=f0,fl1=f1,nf;
	for(ll i=2;i<=x;i++)
	{
		nf=(fl1<<1)+(fl2<<1)+fl2;
		fl2=fl1;
		fl1=nf%md;
	}
	
	return fl1;
}

void dfs(int u,int s)
{
	if(s==k)
	{
		(ans+=calc(sum))%=md;
		return;
	}

	for(int i=u+1;i<=n;i++)
	{
		sum+=a[i];
		dfs(i,s+1);
		sum-=a[i];
	}
}

int main()
{
	if(fopen("see.in","r")!=NULL)
	{
		freopen("see.in","r",stdin);
		freopen("see.out","w",stdout);
	}

	n=read();k=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	f0=read();
	f1=read();

	dfs(0,0);

	printf("%lld\n",ans);

	return 0;
}
/*
4 2
1 2 1 3
1 1

20 10
125 3162 3261 152 376 238 462 4382 376 4972 16 1872 463 9878 688 308 125 236 3526 543
1223 3412

*/
