#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define x first
#define y second
namespace VT
{
	inline bool check_min(int a,int &b){return a<b?(b=a,1):0;}
	inline bool check_max(int a,int &b){return a>b?(b=a,1):0;}
	typedef std::pair<int,int> pii;
	const int N=101000,M=301000,INF=1000000000;
	int begin[N],cur[N],next[M],to[M],w[M];
	int dfn[N],dep[N],top[N],fa[N];
	int ind[N],stk[N],isit[N],du[N];
	pii egf[N];
	int f[N],df[N];
	int dl[N],vis[N],sp[N];
	int n,m,e,oe,rt,cnt,tot,ans,dfn_cnt,num;
	int ask(int p){return top[p]==p?p:top[p]=ask(top[p]);}
	inline bool com(pii i,pii j){return dfn[i.x]<dfn[j.x];}
	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	int pre_dfs(int p,int h)
	{
		dep[p]=dep[h]+1;
		top[p]=p;fa[p]=h;
		dfn[p]=++dfn_cnt;
		int sizp=1,sizq,maxsiz=0,maxson=0;
		for(int i=begin[p],q;i;i=next[i])
		{
			if((q=to[i])==h)continue;
			if(check_max(sizq=pre_dfs(q,p),maxsiz))maxson=q;
			sizp+=sizq;
		}
		top[maxson]=p;
		return sizp;
	}
	void Add(int x,int y,int z,bool k=1)
	{
//		if(k)printf("%d -- %d  : %d\n",ind[x],ind[y],z);
		to[++e]=y;
		next[e]=cur[x];
		cur[x]=e;
		w[e]=z;
		if(k)Add(y,x,z,0);
	}
	int get_lca(int u,int v){return ask(u)==ask(v)?(dep[u]<dep[v]?u:v):(dep[ask(u)]<dep[ask(v)]?get_lca(u,fa[ask(v)]):get_lca(fa[ask(u)],v));}
	void pop()
	{
		Add(stk[cnt-1],stk[cnt],stk[cnt][ind][dep]-stk[cnt-1][ind][dep]);
		if(stk[cnt][isit] && stk[cnt-1][isit])check_max((stk[cnt][ind][dep]-stk[cnt-1][ind][dep])/2,ans);
		cnt--;
	}
	void build_tree()
	{
		int tmp=tot,i,lca;
		rt=egf[1].x;
		for(i=1;i<=num;i++)egf[++tmp]=pii(sp[i],0);
		std::sort(egf+1,egf+tmp+1,com);
		tot=0;
		for(i=1;i<=tmp;i++)
			if(egf[i].x!=egf[i-1].x)
			{
				rt=get_lca(rt,ind[++tot]=egf[i].x);
				isit[tot]=egf[i].y;
				cur[tot]=0;
			}
			else isit[tot]=1;
		tmp=tot;
		cnt=1;
		if(rt!=ind[1])ind[++tot]=rt,cur[tot]=isit[tot]=0,i=1,stk[1]=tot;
		else i=2,stk[1]=1;
		for(;i<=tmp;i++)
		{

			if((lca=get_lca(stk[cnt][ind],ind[i]))==stk[cnt][ind])stk[++cnt]=i;
			else 
			{
				while(cnt>1 && stk[cnt-1][ind][dep]>=lca[dep])pop();
				if(stk[cnt][ind]!=lca)
				{
					ind[++tot]=lca;cur[tot]=isit[tot]=0;
					stk[cnt+1]=stk[cnt];stk[cnt]=tot;cnt++;
					pop();
				}
				stk[++cnt]=i;
			}
		}
		while(cnt>1)pop();
	}
	void query()
	{
		scanf("%d",&tot);
		for(int i=1;i<=tot;i++)scanf("%d",&egf[i].x),egf[i].y=1;
		ans=0;
		build_tree();
		int u=0,d=0;
		for(int i=1;i<=tot;i++)
			if(isit[i])dl[++u]=i,vis[i]=1,f[i]=0;
			else vis[i]=0,f[i]=INF;
		for(int p,q;u>d;)
		{
			p=dl[++d];
			for(int i=cur[p];i;i=next[i])
				if(check_min(f[p]+w[i],f[q=to[i]]))dl[++u]=q,vis[q]=1;
		}
		for(int i=1;i<=tot;i++)check_max(f[i],ans);
		printf("%d\n",ans);
		e=oe;
	}
	void getsp()
	{
		num=0;
		for(int i=1;i<=n;i++)
			if(du[i]==1)sp[++num]=i;
	}
	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=1,x,y;i<n;i++)
			scanf("%d%d",&x,&y),add(x,y),du[x]++,du[y]++;
		pre_dfs(1,0);
		getsp();
		oe=e;
	}
	void solve()
	{
		initialize();
		while(m--)query();
	}
}
int main()
{
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	VT::solve();
	return 0;
}
