#include<iostream>
#include<cstdio>
#include<cstring>
const int N=50,MOD=99991,I4=24998;
typedef long long ll;
ll qpow(ll a,ll b)
{
	ll c=1;
	for(;b;b>>=1,a=a*a%MOD)
		if(b&1)c=c*a%MOD;
	return c;
}
int n,k;
ll a[N];
ll f0,f1,ans;
ll calc(ll p){return ((qpow(3,p)+((p&1)?1:-1))*I4%MOD*(f0+f1)%MOD+((p&1)?-f0:f0))%MOD;}
void dfs(int p=1,int cnt=0,ll sum=0)
{
	if(cnt==k)
	{
		ans=(ans+calc(sum))%MOD;
		return;
	}
	for(int i=p;i<=n;i++)
		dfs(i+1,cnt+1,sum+a[i]);
}
int main()
{
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)scanf("%lld",a+i);
	scanf("%lld%lld",&f0,&f1);
	ans=0;
	dfs();
	printf("%lld\n",ans);
	return 0;
}
