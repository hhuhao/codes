#include<iostream>
#include<cstdio>
#include<cstring>
const int N=210,M=5050;
char s[N][M];
int f[M][M],len[N];
int ans[9];
int n;
void initialize()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%s",s[i]),len[i]=strlen(s[i]);
}
int check(int x,int y)
{
	if(len[x]<len[y])std::swap(x,y);

	for(int i=1;i<=len[x];i++)f[i][0]=i;
	for(int i=1;i<=len[y];i++)f[0][i]=i;

	for(int i=1;i<=len[x];i++)
		for(int j=1;j<=len[y];j++)
			if(s[x][i-1]!=s[y][j-1])f[i][j]=std::min(f[i-1][j-1]+1,std::min(f[i-1][j]+1,f[i][j-1]+1));
			else f[i][j]=f[i-1][j-1];
	return f[len[x]][len[y]]<=8?f[len[x]][len[y]]:0;
}
void solve()
{
	initialize();
	for(int i=1;i<=n;i++)
		for(int j=1;j<i;j++)
			ans[check(i,j)]++;
	for(int i=1;i<=8;i++)
		printf("%d ",ans[i]);
	printf("\n");
}
int main()
{
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	solve();
	return 0;
}
