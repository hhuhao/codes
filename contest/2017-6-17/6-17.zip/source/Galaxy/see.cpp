#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

#define Rep(i, s, t) for(int i = (s), i##E = (t); i <= i##E; ++i)
#define Dec(i, s, t) for(int i = (s), i##E = (t); i >= i##E; --i)

using namespace std;

typedef long long LL;

const int MX_N = 5e3 + 10;
const int Mod = 99991;

int n, k;
int a[MX_N];

struct Matrix {
	int x[2][2];
	Matrix() {memset(x, 0, sizeof x);}
	void init() {
		x[0][0] = 2, x[0][1] = 3;
		x[1][0] = 1;
	}
}tmp;

Matrix operator * (Matrix a, Matrix b) {
	Rep(i, 0, 1)Rep(j, 0, 1) {
		tmp.x[i][j] = 0;
		Rep(k, 0, 1) 
			tmp.x[i][j] = (tmp.x[i][j] + (LL) a.x[i][k] * b.x[k][j] % Mod) % Mod;
	}return tmp;
}

Matrix operator ^ (Matrix a, LL d) {
	Matrix ret = a;
	for(--d; d; a = a * a, d >>= 1LL) {
		if(d & 1LL) ret = ret * a;
	}
	return ret;
}

LL f[MX_N * 10];

LL calc(LL d) {
	if(d <= 1) return 1;
	Matrix ret; ret.init();
	ret = ret ^ (d - 1);
	return (f[1] * ret.x[0][0] % Mod + f[0] * ret.x[0][1] % Mod) % Mod;
}

namespace BF {
	void solve() {
		int ans = 0;
		Rep(i, 0, (1 << n) - 1) {
			if(__builtin_popcount(i) ^ k) continue;
			LL sum = 0;
			Rep(j, 1, n) if(i & (1 << (j - 1))) sum += a[j];
			ans = (ans + calc(sum)) % Mod;
		}printf("%d\n", ans % Mod);
	}
}

namespace Special {
	const int W = 1e4;
	int g[W + 10][110], times[W + 10][110];
	
	void solve() {
		LL ans = 0;
		int tmp = 0;
		g[0][0] = 1, times[0][0] = 1;
		Rep(i, 1, n)Dec(w, W - a[i], 0) 
			Rep(j, 1, k) {
				g[w + a[i]][j] |= g[w][j-1];
				times[w + a[i]][j] += times[w][j-1];
			}
		Rep(i, 2, W) f[i] = (f[i-1] * 2 % Mod + f[i-2] * 3 % Mod) % Mod;
		Rep(i, 1, W) if(g[i][k])
			ans = (ans + f[i] * times[i][k] % Mod) % Mod;
		printf("%lld\n", ans);
	}
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("see.in", "r", stdin);
	freopen("see.out", "w", stdout);
#endif
	scanf("%d%d", &n, &k);
	Rep(i, 1, n) scanf("%d", &a[i]);
	scanf("%lld%lld", &f[0], &f[1]);
	if(n <= 20) BF::solve();
	else Special::solve();
	return 0;
}
