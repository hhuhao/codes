#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

#define Rep(i, s, t) for(int i = (s), i##E = (t); i <= i##E; ++i)
#define Dec(i, s, t) for(int i = (s), i##E = (t); i >= i##E; --i)

using namespace std;

const int maxn = 1e5 + 10;

template <class T> T read(T &x, T f = 0) {
	char c = getchar(); x = 0;
	while(c < '0' || c > '9') {if(c=='-') f = 1; c = getchar();}
	while(c >= '0' && c <= '9') x = x*10 + c-'0', c = getchar();
	return x = f? -x : x;
}

int n, q;

int e, Begin[maxn];
int To[maxn << 1], Next[maxn << 1];
int dep[maxn], fa[maxn], d[maxn];

void Add(int u, int v) {
	To[++e] = v;
	Next[e] = Begin[u];
	Begin[u] = e;
}

namespace BF {
	int dis[1000 + 10][1000 + 10];
	int hson[maxn], top[maxn], sz[maxn];

	void dfs(int u) {
		sz[u] = 1;
		for(int i = Begin[u]; i; i = Next[i])
			if(To[i] != fa[u]) {
				dep[To[i]] = dep[u] + 1;
				fa[To[i]] = u;
				dfs(To[i]);
				sz[u] += sz[To[i]];
				if(sz[To[i]] > sz[hson[u]]) hson[u] = To[i];
			}
	}

	void dfn(int u, int T) {
		top[u] = T;
		if(hson[u]) dfn(hson[u], top[u]);
		for(int i = Begin[u]; i; i = Next[i]) 
			if(To[i] != fa[u] && To[i] != hson[u])
				dfn(To[i], To[i]);
	}

	int Lca(int u, int v) {
		while(top[u] != top[v]) {
			if(dep[top[u]] < dep[top[v]]) swap(u, v);
			u = fa[top[u]];
		}
		return dep[u] < dep[v]? u : v;
	}

	int stk[maxn];

	void main() {
		fa[1] = 1, dfs(1);
		top[1] = 1, dfn(1, 1);
		Rep(i, 1, n)Rep(j, i + 1, n)
			dis[i][j] = dis[j][i] = dep[i] + dep[j] - 2 * dep[Lca(i, j)];
		Rep(i, 1, q) {
			int k, ans = 0; 
			read(k); Rep(j, 1, k) read(stk[j]);
			Rep(j, 1, n) {
				int ret = n;
				Rep(l, 1, k) ret = min(ret, dis[j][stk[l]]);
				ans = max(ret, ans);
			}printf("%d\n", ans);
		}
	}
}

namespace Special {
	void dfs(int u) {
		for(int i = Begin[u]; i; i = Next[i])
			if(To[i] != fa[u]) {
				dep[To[i]] = dep[u] + 1;
				fa[To[i]] = u; dfs(To[i]);
			}
	}

	int stk[maxn];

	void main() {
		Rep(i, 1, n) if(d[i] == 1) {
			dfs(i); break;
		}
		Rep(i, 1, q) {
			int k, x, ans; read(k);
			Rep(j, 1, k) read(x), stk[j] = dep[x];
			sort(stk + 1, stk + k + 1);
			ans = max(n - 1 - stk[k], stk[1]);
			Rep(j, 1, k - 1) ans = max(ans, (stk[j + 1] - stk[j]) / 2);
			printf("%d\n", ans);
		}
	}
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("do.in", "r", stdin);
	freopen("do.out", "w", stdout);
#endif
	read(n), read(q);
	Rep(i, 1, n - 1) {
		static int u, v;
		read(u), read(v);
		Add(u, v), Add(v, u);
		++d[u], ++d[v];
	}
	int c1 = 0, c2 = 0;
	Rep(i, 1, n) 
		if(d[i] == 1) ++c1;
		else if(d[i] == 2) ++c2;
	if(c1 == 2 && c2 == n - 2) Special :: main();
	else BF :: main();
	return 0;
}
