#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

#define Rep(i, s, t) for(int i = (s), i##E = (t); i <= i##E; ++i)
#define Dec(i, s, t) for(int i = (s), i##E = (t); i >= i##E; --i)

using namespace std;

const int MX_N = 5e3 + 10;

int c[9];
int n, len[MX_N];
char s[MX_N][MX_N];
int ans[MX_N][MX_N], f[MX_N][MX_N];

int main() {
#ifndef ONLINE_JUDGE
	freopen("say.in", "r", stdin);
	freopen("say.out", "w", stdout);
#endif
	scanf("%d", &n);
	Rep(i, 1, n) {
		scanf("%s", s[i] + 1);
		len[i] = strlen(s[i] + 1);
	}
	Rep(i, 1, n)Rep(j, i + 1, n) {
		Rep(k, 1, len[i])Rep(l, 1, len[j]) f[k][l] = 0;
		Rep(k, 1, len[i])Rep(l, 1, len[j])
			if(s[i][k] == s[j][l]) 
				f[k][l] = max(f[k-1][l-1] + 1, max(f[k-1][l], f[k][l-1]));
			else f[k][l] = max(f[k-1][l], f[k][l-1]);
		ans[i][j] = f[len[i]][len[j]];
	}
	Rep(i, 1, n)Rep(j, i + 1, n) {
		int t = abs(len[i] - len[j]) + max(len[i], len[j]) - ans[i][j];
		if(t <= 8) ++c[t];
	}
	Rep(i, 1, 8) printf("%d%c", c[i], i ^ 8? ' ':'\n');
	return 0;
}
