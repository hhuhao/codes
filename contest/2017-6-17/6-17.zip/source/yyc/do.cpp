#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<algorithm>
using namespace std;
#define REP(i,st,ed) for(int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(int i=st,i##end=ed;i>=i##end;--i)
namespace ioput{
	template<typename T>T read(){
		T x=0,f=1;
		char c=getchar();
		while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
		while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
		return x*f;
	}
	template<typename T>void write(T x,char c){
		static char t[20];
		static int tlen;
		t[tlen=1]=c;
		do t[++tlen]=(x%10)^48,x/=10;
		while(x);
		while(tlen)putchar(t[tlen--]);
	}
}
using namespace ioput;
const int maxn=100005,inf=0x3f3f3f3f;
int n,q_cnt;
int deg[maxn];
int Begin[maxn],Next[maxn<<1],to[maxn<<1],e;
void add_edge(int u,int v){
	to[++e]=v,Next[e]=Begin[u],Begin[u]=e;
}
namespace solver_1{
	int dis[maxn];
	queue<int>Q;
	void init(){
		while(!Q.empty())Q.pop();
		memset(dis,inf,sizeof(dis));
	}
	int bfs(){
		while(1){
			int u=Q.front();Q.pop();
			for(int i=Begin[u];i;i=Next[i]){
				int v=to[i];
				if(dis[v]>dis[u])
					dis[v]=dis[u]+1,Q.push(v);
			}if(Q.empty())return dis[u];
		}
	}
	void work(){
		int m,u;
		REP(kase,1,q_cnt){
			init();
			m=read<int>();
			REP(i,1,m){
				u=read<int>();
				Q.push(u),dis[u]=0;
			}write(bfs(),'\n');
		}
	}
}
namespace solve_2{
	int dep[maxn];
	void dfs(int u){
		for(int i=Begin[u];i;i=Next[i]){
			int v=to[i];
			if(!dep[v])
				dep[v]=dep[u]+1,dfs(v);
		}
	}
	void work(){
		static int t[maxn];
		int st,m,u;
		REP(i,1,n)
			if(deg[i]==1)st=i;
		dep[st]=1,dfs(st);
		REP(kase,1,q_cnt){
			m=read<int>();
			REP(i,1,m){
				u=read<int>();
				t[i]=dep[u];
			}sort(t+1,t+1+m);
			int ans=max(t[1]-1,n-t[m]);
			REP(i,2,m)ans=max(ans,(t[i]-t[i-1])/2);
			write(ans,'\n');
		}
	}
}
namespace solver_3{
	int Maxdep[maxn],dep[maxn],Maxdis[maxn],fa[maxn][18];
	void dfs(int u){
		Maxdep[u]=u;
		int Sec=0;
		for(int i=Begin[u];i;i=Next[i]){
			int v=to[i];
			if(v!=fa[u][0]){
				fa[v][0]=u,dep[v]=dep[u]+1;
				REP(j,1,17)fa[v][j]=fa[fa[v][j-1]][j-1];
				dfs(v);
				if(dep[Maxdep[v]]>dep[Maxdep[u]])Sec=Maxdep[u],Maxdep[u]=Maxdep[v];
				else if(dep[Maxdep[v]]>dep[Sec])Sec=Maxdep[v];
			}
		}
		for(int i=Begin[u];i;i=Next[i]){
			Maxdis[to[i]]=Maxdis[u]+1;
			if(Maxdep[to[i]]==Maxdep[u])Maxdis[to[i]]=max(Maxdis[to[i]],dep[Sec]-dep[u]+1);
			else Maxdis[to[i]]=max(Maxdis[to[i]],dep[Maxdep[u]]-dep[u]+1);
		}
	}
	int get_lca(int u,int v){
		if(dep[u]<dep[v])swap(u,v);
		DREP(i,17,0)
			if(dep[fa[u][i]]>=dep[v])u=fa[u][i];
		if(u==v)return u;
		DREP(i,17,1)
			if(fa[u][i]!=fa[v][i])u=fa[u][i],v=fa[v][i];
		return fa[u][0];
	}
	int find_fa(int u,int d){
		DREP(i,17,0)
			if((1<<i)<=d)d-=1<<i,u=fa[u][i];
		return u;
	}
	int t[maxn],c[maxn],mark[maxn];
	bool pd[maxn],vis[maxn];
	void work(){
		dep[1]=1,dfs(1);
		int m,u;
		REP(kase,1,q_cnt){
			m=read<int>();
			memset(vis,0,sizeof(vis));
			REP(i,1,m)
				t[i]=read<int>(),c[i]=mark[i]=0,vis[Maxdep[t[i]]]=1;
			int ans=0;
			if(m==1){
				printf("%d %d\n",dep[Maxdep[t[1]]]-dep[t[1]],Maxdis[t[1]]);
				ans=max(dep[Maxdep[t[1]]]-dep[t[1]],Maxdis[t[1]]);
				write(ans,'\n');
				continue;
			}
			REP(i,1,m)
				REP(j,i+1,m){
					int x=i,y=j,lca;
					if(dep[t[x]]>dep[t[y]])swap(x,y);
					lca=get_lca(t[x],t[y]);
					if((dep[lca]>dep[c[y]])||((dep[lca]==dep[c[y]])&&(dep[u]<dep[mark[y]])))
						c[y]=lca,mark[y]=t[x];
				}
			int rt=0;
			REP(i,1,m){
				pd[c[i]]=1;
				if((!rt)||(dep[c[i]]<dep[rt]))rt=c[i];
			}
			REP(i,1,m){
				if(!pd[t[i]])ans=max(ans,dep[Maxdep[t[i]]]-dep[t[i]]);
				if(!c[i])continue;
				int d1=dep[t[i]]-dep[c[i]],d2=dep[mark[i]]-dep[c[i]];
				if(c[i]==rt)ans=max(ans,d2+Maxdis[rt]);
				int cut=find_fa(t[i],(d1+d2)/2);
				ans=max(ans,(d1+d2)/2);
				for(int j=Begin[cut];j;j=Next[j])
					if(!vis[Maxdep[to[j]]])ans=max(ans,(d1+d2)/2+dep[Maxdep[to[j]]]-dep[cut]);
			}
			write(ans,'\n');
			REP(i,1,m)
				printf("%d %d %d\n",t[i],c[i],mark[i]);
			puts("");
		}
	}
}
void solve(){
	if(n*q_cnt<=9000000)return solver_1::work();
	int c1=0,c2=0;
	REP(i,1,n){
		if(deg[i]==1)++c1;
		else if(deg[i]==2)++c2;
	}if((c1==2)&&(c2==n-2))return solve_2::work();
//	solver_3::work();
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
#endif
	n=read<int>(),q_cnt=read<int>();
	REP(i,1,n-1){
		int u=read<int>(),v=read<int>();
		add_edge(u,v),add_edge(v,u);
		++deg[u],++deg[v];
	}solve();
	return 0;
}
