#include<iostream>
#include<cstdio>
using namespace std;
#define REP(i,st,ed) for(int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(int i=st,i##end=ed;i>=i##end;--i)
namespace ioput{
	template<typename T>T read(){
		T x=0,f=1;
		char c=getchar();
		while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
		while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
		return x*f;
	}
	template<typename T>void write(T x,char c){
		static char t[20];
		static int tlen;
		t[tlen=1]=c;
		do t[++tlen]=(x%10)^48,x/=10;
		while(x);
		while(tlen)putchar(t[tlen--]);
	}
}
using namespace ioput;
struct Matrix{
	int s[2][2];
	Matrix(){}
	Matrix(int x){REP(i,0,1)REP(j,0,1)s[i][j]=x;}
}A,B,Res,Tmp,Ans;
const int maxn=100005,mod=99991;
int n,k,a[maxn];
void Mul(const Matrix &Tmp,Matrix &Res){
	Ans=0;
	REP(i,0,1)
		REP(j,0,1){
			REP(k,0,1)
				Ans.s[i][j]=Ans.s[i][j]+1ll*Tmp.s[i][k]*Res.s[k][j]%mod;
			Ans.s[i][j]%=mod;
		}
	Res=Ans;
}
int fib(long long y){
	Res=A,Tmp=B;
	while(y){
		if(y&1)Mul(Tmp,Res);
		Mul(Tmp,Tmp),y>>=1;
	}return Res.s[0][0];
}
int ans=0;
void dfs(int step,int cnt,long long sum){
	if(cnt==k){ans=(ans+fib(sum))%mod;return;}
	else if(step>n)return;
	dfs(step+1,cnt,sum);
	dfs(step+1,cnt+1,sum+a[step]);
}
int main(){
#ifndef ONLINE_JUDTmpE
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
#endif
	n=read<int>(),k=read<int>();
	REP(i,1,n)a[i]=read<int>();
	A.s[0][0]=read<int>(),A.s[1][0]=read<int>();
	B.s[0][0]=0,B.s[0][1]=1,B.s[1][0]=3,B.s[1][1]=2;
	dfs(1,0,0);
	write(ans,'\n');
	return 0;
}
