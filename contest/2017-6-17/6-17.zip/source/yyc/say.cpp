#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>L:
using namespace std;
#define REP(i,st,ed) for(int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(int i=st,i##end=ed;i>=i##end;--i)
namespace ioput{
	template<typename T>T read(){
		T x=0,f=1;
		char c=getchar();
		while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
		while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
		return x*f;
	}
	template<typename T>void write(T x,char c){
		static char t[20];
		static int tlen;
		t[tlen=1]=c;
		do t[++tlen]=(x%10)^48,x/=10;
		while(x);
		while(tlen)putchar(t[tlen--]);
	}
}
using namespace ioput;
const int maxn=205,maxlen=1000005;
char s[maxlen];
int cnt[maxn][26],len[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
#endif
	int n=read<int>();
	REP(i,1,n){
		scanf("%s",s+1);
		len[i]=strlen(s+1);
		REP(j,1,len[i])
			pos[i][s[j]-'a'].push_back(j);
	}
	REP(i,1,n)
		REP(j,1,n)
			REP(k,0,25){
				printf("%d %d %d\n",i,j,k);
				REP(l,0,pos
			}
	return 0;
}
