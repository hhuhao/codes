/*************************************************************************
    > Author: Drinkwater-cnyali
    > Created Time: 2017/6/17 8:58:35
 ************************************************************************/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>

using namespace std;

typedef long long LL;

#define REP(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++ i)
#define DREP(i, a, b) for(register int i = (a), i##_end_ = (b); i >= i##_end_; -- i)
//char buff[1<<25], *buf = buff;
#define mem(a, b) memset((a), b, sizeof(a))

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

/*int Fread()
{
	int sum = 0, fg = 1;
	for(; !isdigit(*buf) ; ++buf)if(*buf == '-')fg = -1;
	for(; isdigit(*buf); ++buf)sum = sum * 10 + *buf - '0';
	return sum * fg;
}*/

int read()
{
	int sum = 0,fg = 1;char c = getchar();
	while(c < '0' || c > '9') { if (c == '-') fg = -1; c = getchar(); }
	while(c >= '0' && c <= '9') { sum = sum * 10 + c - '0'; c = getchar(); }
	return sum * fg;
}

const int maxn = 100000;
const int inf = 0x3f3f3f3f;

int n,k;
int a[maxn],f[maxn],rnk[maxn];
const int mod = 99991;
int ans = 0;

void dfs(int x,int cnt,int sum)
{
	if(cnt == k)
	{
		ans = (ans + f[sum])%mod;
		return ;
	}
	REP(i,x,n)dfs(i+1,cnt+1,sum+a[i]);
}

int main()
{
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	n = read(), k = read();
	REP(i,1,n)a[i] = read();
	f[0] = read(), f[1] = read();
	REP(i,2,maxn)f[i] = (2 * f[i-1] % mod + 3 * f[i-2] % mod) % mod;
	dfs(1,0,0);
	printf("%d\n",ans);
    return 0;
}
