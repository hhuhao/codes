/*************************************************************************
    > Author: Drinkwater-cnyali
    > Created Time: 2017/6/17 11:11:19
 ************************************************************************/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>

using namespace std;

typedef long long LL;

#define REP(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++ i)
#define DREP(i, a, b) for(register int i = (a), i##_end_ = (b); i >= i##_end_; -- i)
//char buff[1<<25], *buf = buff;
#define mem(a, b) memset((a), b, sizeof(a))

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

/*int Fread()
{
	int sum = 0, fg = 1;
	for(; !isdigit(*buf) ; ++buf)if(*buf == '-')fg = -1;
	for(; isdigit(*buf); ++buf)sum = sum * 10 + *buf - '0';
	return sum * fg;
}*/

int read()
{
	int sum = 0,fg = 1;char c = getchar();
	while(c < '0' || c > '9') { if (c == '-') fg = -1; c = getchar(); }
	while(c >= '0' && c <= '9') { sum = sum * 10 + c - '0'; c = getchar(); }
	return sum * fg;
}

const int maxn = 300000;
const int inf = 0x3f3f3f3f;

int n,q;
int be[maxn],ne[maxn],to[maxn],e;
int size[maxn],son[maxn],dep[maxn],fa[maxn];
int vis[maxn];

void add(int x,int y)
{
	to[++e] = y;ne[e] = be[x];
	be[x] = e;
}

void dfs1(int x,int dp)
{
	vis[x] = 1;dep[x] = dp;size[x] = 1;
	for(int i = be[x]; i; i = ne[i])
	{
		int v = to[i];
		if(!vis[v])
		{
			fa[v] = x;dfs1(v,dp+1);
			size[x] += size[v];
			if(!son[x] || size[son[x]] < size[v])
				son[x] = v;
		}
	}
}

int top[maxn],tid[maxn],cnt,p[maxn];

void dfs2(int x,int tp)
{
	top[x] = tp;tid[x] = ++cnt;
	vis[x] = 1;
	if(!son[x])return ;
	dfs2(son[x],tp);
	for(int i = be[x]; i; i = ne[i])
	{
		int v = to[i];
		if(!vis[v])
			dfs2(v,v);
	}
}

int LCA(int x,int y)
{
	while(top[x] != top[y])
	{
		if(dep[top[x]] < dep[top[y]])swap(x,y);
		x = fa[top[x]];
	}
	if(x == y)return x;
	if(dep[x] < dep[y])return x;
	if(dep[y] < dep[x])return y;
	return 0;
}

int main()
{
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	n = read(), q = read();
	REP(i,1,n-1)
	{
		int x = read(), y = read();
		add(x,y);add(y,x);
	}
	dfs1(1,1);memset(vis,0,sizeof(vis));
	dfs2(1,1);
	REP(I,1,q)
	{
		int k = read();
		memset(vis,0,sizeof(vis));
		REP(i,1,k)p[i] = read(),vis[p[i]] = 1;
		int ans = 0;
		REP(i,1,n)
		{
			int mina = inf;
			if(!vis[i])
				REP(j,1,k)
					mina = min(mina,dep[p[j]]+dep[i]-dep[LCA(p[j],i)]*2);
			if(mina!=inf)ans = max(ans,mina);
		}
		printf("%d\n",ans);
	}
    return 0;
}
