/*************************************************************************
	 > Author: wzw-cnyali
	 > Created Time: 2017/6/17 11:28:17
 ************************************************************************/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>

using namespace std;

typedef long long LL;

typedef unsigned long long uLL;

#define REP(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++ i)
#define DREP(i, a, b) for(register int i = (a), i##_end_ = (b); i >= i##_end_; -- i)
#define EREP(i, a) for(register int i = (be[a]); i != -1; i = nxt[i])
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mem(a, b) memset((a), b, sizeof(a))

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

template <class T>
T read(T sum = 0, T fg = 0)
{
	char c = getchar();
	while(c < '0' || c > '9') { fg |= c == '-'; c = getchar(); }
	while(c >= '0' && c <= '9') { sum = sum * 10 + c - '0'; c = getchar(); }
	return fg ? -sum : sum;
}

const int inf = 1e9;

const LL INF = 1e17;

const int Size = 200;

const int maxn = 1000000;

const int maxm = 100000;

int Slen[Size];
char S[Size][maxn];

int main()
{
	freopen("say.in", "r", stdin);
	freopen("say.out", "w", stdout);
	int n = read<int>();
	REP(i, 0, n - 1)
	{
		scanf("%s", S[i]);
		Slen[i] = strlen(S[i]);
	}
	REP(i, 1, 8)
	{
		cout << 0 << " ";
	}
	return 0;
}
