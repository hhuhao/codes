/*************************************************************************
	 > Author: wzw-cnyali
	 > Created Time: 2017/6/17 11:06:34
 ************************************************************************/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>

using namespace std;

typedef long long LL;

typedef unsigned long long uLL;

#define REP(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++ i)
#define DREP(i, a, b) for(register int i = (a), i##_end_ = (b); i >= i##_end_; -- i)
#define EREP(i, a) for(register int i = (be[a]); i != -1; i = nxt[i])
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mem(a, b) memset((a), b, sizeof(a))

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

char buff[1 << 25], *buf = buff;

template <class T>
T read(T sum = 0, T fg = 0)
{
	while(*buf < '0' || *buf > '9') { fg |= *buf == '-'; buf++; }
	while(*buf >= '0' && *buf <= '9') { sum = sum * 10 + *buf - '0'; buf++; }
	return fg ? -sum : sum;
}

const int inf = 1e9;

const LL INF = 1e17;

const int Size = 5000000;

const int maxn = 100010;

const int maxm = 100000;

const int mod = 99991;

int n, k;
int f[Size];

int get_f(int x)
{
	if(f[x]) return f[x];
	else return f[x] = ((2 * get_f(x - 1)) % mod + (3 * get_f(x - 2)) % mod) % mod;
}

int a[maxn];
bool vis[maxn];
int ans;

void dfs(int pos, int num, int sum)
{
	if(num == k)
	{
		ans = ((ans % mod) + (get_f(sum) % mod)) % mod;
		return;
	}
	REP(i, pos, n)
	{
		if(!vis[i])
		{
			vis[i] = 1;
			dfs(i + 1, num + 1, sum + a[i]);
			vis[i] = 0;
		}
	}
}

int main()
{
	freopen("see.in", "r", stdin);
	freopen("see.out", "w", stdout);
	fread(buff, 1, 1 << 25, stdin);

	n = read<int>(), k = read<int>();
	REP(i, 1, n) a[i] = read<int>();
	f[0] = read<int>(), f[1] = read<int>();

	dfs(1, 0, 0);
	printf("%d\n", ans);
	return 0;
}
