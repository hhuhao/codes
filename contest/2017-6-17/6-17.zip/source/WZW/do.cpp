/*************************************************************************
	 > Author: wzw-cnyali
	 > Created Time: 2017/6/17 11:45:34
 ************************************************************************/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>

using namespace std;

typedef long long LL;

typedef unsigned long long uLL;

#define REP(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++ i)
#define DREP(i, a, b) for(register int i = (a), i##_end_ = (b); i >= i##_end_; -- i)
#define EREP(i, a) for(register int i = (be[a]); i != -1; i = nxt[i])
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mem(a, b) memset((a), b, sizeof(a))

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

char buff[1 << 26], *buf = buff;

template <class T>
T read(T sum = 0, T fg = 0)
{
	while(*buf < '0' || *buf > '9') { fg |= *buf == '-'; buf++; }
	while(*buf >= '0' && *buf <= '9') { sum = sum * 10 + *buf - '0'; buf++; }
	return fg ? -sum : sum;
}

const int inf = 1e9;

const LL INF = 1e17;

const int Size = 400010;

const int maxn = 100000;

const int maxm = 5010;

int be[Size], to[Size], nxt[Size], w[Size], e;

void add(int x, int y) { to[e] = y; nxt[e] = be[x]; be[x] = e; w[e] = 1; e++; }

void init() { mem(be, -1); e = 0; }

bool vis[Size];
int deep[Size], son[Size], siz[Size], fa[Size];

void dfs1(int x, int depth, int f)
{
	vis[x] = 1;
	siz[x] = 1; deep[x] = depth;
	fa[x] = f;
	EREP(i, x)
	{
		int y = to[i];
		if(!vis[y])
		{
			vis[y] = 1;
			dfs1(y, depth + 1, x);
			siz[x] += siz[y];
			if(!son[x] || siz[y] > siz[son[x]]) son[x] = y;
		}
	}
}

int tid[Size], top[Size], cnt;

void dfs2(int x, int f)
{
	vis[x] = 1;
	tid[x] = ++cnt; top[x] = f;
	if(!son[x]) return;
	dfs2(son[x], f);
	EREP(i, x)
	{
		int y = to[i];
		if(!vis[y] && y != son[x]) dfs2(y, y);
	}
}

int LCA(int x, int y)
{
	while(top[x] != top[y])
	{
		if(deep[top[x]] < deep[top[y]]) swap(x, y);
		x = fa[top[x]];
	}
	return deep[x] < deep[y] ? x : y;
}

int must[Size];
int dist[maxm][maxm];

int main()
{
	freopen("do.in", "r", stdin);
	freopen("do.out", "w", stdout);

	fread(buff, 1, 1 << 26, stdin);
	init();
	int n = read<int>(), q = read<int>();
	REP(i, 1, n - 1)
	{
		int x = read<int>(), y = read<int>();
		add(x, y); add(y, x);
	}

	dfs1(1, 0, -1);
	mem(vis, 0);
	dfs2(1, 1);

	while(q--)
	{
		mem(vis, 0);
		int k = read<int>();
		REP(i, 1, k) vis[must[i] = read<int>()] = 1;

		int last_ans = 0;
		REP(i, 1, n)
		{
			if(vis[i]) continue;
			int MIN = inf;
			REP(j, 1, k)
			{
				if(dist[i][must[j]])
				{
					chkmin(MIN, dist[i][must[j]]);
					continue;
				}
				int lca = LCA(i, must[j]);
				int ans = deep[i] + deep[must[j]] - deep[lca] * 2;
				dist[i][must[j]] = ans;
				chkmin(MIN, ans);
			}
			chkmax(last_ans, MIN);
		}
		printf("%d\n", last_ans);
	}
	return 0;
}
