#include<bits/stdc++.h>
#define For(i,j,k) for(int i=(j);i<=(int)k;i++)
#define Forr(i,j,k) for(int i=(j);i>=(int)k;i--)
#define ll long long 
using namespace std;
const int N=200010,INF=0x3f3f3f3f;
const ll Mod=99991;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(c<'0'||c>'9')f|=(c=='-'),c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^48),c=getchar();
	x=f?-x:x;
}
ll qpow(ll a,ll b){
	ll ret=1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
ll inv(ll x){return qpow(x,Mod-2);}
ll F1[2][N],n,c2,c1,f1,f0,k,a[N],F2[2][N];
int main(){
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	read(n),read(k);
	For(i,1,n)read(a[i]);
	read(f0),read(f1);
	c1=(f1+f0)*inv(4)%Mod;c2=(f0-c1+Mod)%Mod;
	For(i,1,n){
		int x=qpow(3,a[i]);
		F1[(i&1)^1][0]=c1;
		For(j,1,k)
			F1[i&1][j]=F1[(i&1)^1][j]+F1[(i&1)^1][j-1]*x%Mod;
	}
	F2[0][0]=c2;
	For(i,1,n){
		int x=qpow(Mod-1,a[i]);
		F2[(i&1)^1][0]=c2;
		For(j,1,k)
			F2[i&1][j]=F2[(i&1)^1][j]+F2[(i&1)^1][j-1]*x%Mod;
	}
	printf("%lld\n",(F1[n&1][k]+F2[n&1][k])%Mod);
	return 0;   
}
