#include<bits/stdc++.h>
#define For(i,j,k) for(int i=(j);i<=(int)k;i++)
#define Forr(i,j,k) for(int i=(j);i>=(int)k;i--)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N=100010,INF=0x3f3f3f3f;
template<class T>inline void read(T &x){
	x=0;char c=getchar();int f=0;
	while(c<'0'||c>'9')f|=(c=='-'),c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^48),c=getchar();
	x=f?-x:x;
}
int Begin[N],Next[N<<1],to[N<<1],e,top[N],cnt,In[N],son[N],sz[N],fa[N],n,q,Q[N],dep[N];
inline void add(int x,int y){
	to[++e]=y,Next[e]=Begin[x],Begin[x]=e;
}
void dfs1(int u,int f){
	sz[u]=1;
	Rep(i,u)
		if(v!=f)
			dep[v]=dep[u]+1,dfs1(v,u),sz[u]+=sz[v],fa[v]=u,son[u]=sz[v]>sz[son[u]]?v:son[u];
}
void dfs2(int u,int tp){
	top[u]=tp,In[u]=++cnt;
	if(son[u])dfs2(son[u],tp);
	Rep(i,u)
		if(v!=fa[u]&&v!=son[u])
			dfs2(v,v);
}
int Query(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]])swap(x,y);
		x=fa[top[x]];
	}
	if(x==y)return dep[x];
	return dep[x]<dep[y]?dep[x]:dep[y];
}
void Solve1(){
	dfs1(1,1),dfs2(1,1);
	while(q--){
		static int k;
		read(k);
		For(i,1,k)read(Q[i]);
		int mx=0;
		For(i,1,n){
			int dis,ret=INF;
			For(j,1,k){
				dis=dep[i]+dep[Q[j]]-2*Query(i,Q[j]);
				ret=min(dis,ret);
			}
			mx=max(mx,ret);
		}
		printf("%d\n",mx);
	}
}
bool cmp(int x,int y){
	return dep[x]<dep[y];
}
void Solve2(){
	dfs1(1,1);
	while(q--){
		static int k;
		read(k);
		For(i,1,k)read(Q[i]);
		sort(Q+1,Q+k+1,cmp);
		int mx=max(dep[Q[1]],n-1-dep[Q[k]]);
		For(i,2,k)
			mx=max((dep[Q[i]]-dep[Q[i-1]])/2,mx);
		printf("%d\n",mx);
	}
}
int main(){
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	read(n);read(q);
	For(i,1,n-1){
		static int x,y;
		read(x),read(y);
		add(x,y),add(y,x);
	}
	if(n<=3000)Solve1();
	else Solve2();
	return 0;
}
/*
7 5
5 4
6 5
7 3
7 4
1 5
2 4
1 
4 
1 
6 
4 
6 5 7 2 
5 
1 5 4 3 7 
2 
2 3
*/
