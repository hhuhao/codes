#include<bits/stdc++.h>
#define For(i,j,k) for(int i=(j);i<=(int)k;i++)
#define Forr(i,j,k) for(int i=(j);i>=(int)k;i--)
#define Set(a,b) memset(a,b,sizeof(a))
#define ll long long 
using namespace std;
const int N=210,INF=0x3f3f3f3f,M=100010;
template<class T>void read(T &x){
	x=0;char c=getchar();int f=0;
	while(c<'0'||c>'9')f|=(c=='-'),c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^48),c=getchar();
}
string s[N];
int n,ans[9],f[8010][8010];
int check(int x,int y){
	int l1=s[x].length(),l2=s[y].length();
	if(abs(l1-l2)>8)return 9;
	f[0][0]=0;
	For(i,1,l2)f[0][i]=i;
	For(i,1,l1)f[i][0]=i;
	For(i,1,l1)
		For(j,1,l2){
			f[i][j]=min(f[i][j-1],f[i-1][j])+1;
			f[i][j]=min(f[i][j],f[i-1][j-1]+1);
			if(s[x][i-1]==s[y][j-1])
				f[i][j]=min(f[i][j],f[i-1][j-1]);
		}
	return f[l1][l2];
}
int main(){
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	read(n);
	For(i,1,n)cin>>s[i];
	int tmp;
	For(i,1,n)
		For(j,i+1,n)
			if((tmp=check(i,j))<=8)
				ans[tmp]++;
	For(i,1,8)printf("%d ",ans[i]);
	puts("");
	return 0;
}
/*
5 
asxglhxpjdczgmt
sxflkxppkcztnmt
sxglkxpjdzlmt
xglkxxepjdazelmzc
asxglkqmvjddalm
*/
