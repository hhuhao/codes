#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int f[20][5010],ans[100];
char s[210][5010];
int main(){
	int i,j,k,m,n;
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
    scanf("%d",&n);
    for(i=1;i<=n;i++){
	     scanf("%s",s[i]);
	 }
	for(i=1;i<n;i++)
	    for(j=i+1;j<=n;j++){
		    int l1=strlen(s[i]);
			int l2=strlen(s[j]);
			int u=max(l1,l2);
			for(k=0;k<=l1;k++)
			    for(int g=0;g<=l2;g++)f[k%3][g]=10000010;
			f[0][0]=0;    
			for(k=0;k<=l1;k++){
				int d=1;
			    for(int g=0;g<=l2;g++){
			    	if(k!=0 || g!=0)f[k%3][g]=10000010;
			    	if(k>=1 && g>=1)
			    	f[k%3][g]=min(f[k%3][g],f[(k-1)%3][g-1]+1);
			    	if(k>=1)
			    	f[k%3][g]=min(f[k%3][g],f[(k-1)%3][g]+1);
			    	if(g>=1)
			    	f[k%3][g]=min(f[k%3][g],f[k%3][g-1]+1);
			    	if(s[i][k-1]==s[j][g-1] && k && g){
			    		f[k%3][g]=min(f[k%3][g],f[(k-1)%3][g-1]);
			    		if(k>=2)
			    	    f[k%3][g]=min(f[k%3][g],f[(k-2)%3][g-1]+1);
			    	    if(g>=2)
			    	    f[k%3][g]=min(f[k%3][g],f[(k-1)%3][g-2]+1);
			    	}
			        //if(i==1 && j==3)
			        //printf("----%d %d:%d\n",k,g,f[k%3][g]);
		        }
		    //printf("%d %d %d %d\n",i,j,f[l1][l2],u);
		    }
		    if(f[l1%3][l2]<=8)
		    ans[f[l1%3][l2]]++;
		}
	for(i=1;i<=8;i++)
	     printf("%d ",ans[i]);
	return 0;
}
/*
5 
asxglhxpjdczgmt
sxflkxppkcztnmt
sxglkxpjdzlmt
xglkxxepjdazelmzc
asxglkqmvjddalm
*/
