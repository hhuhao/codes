#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
using namespace std;
typedef long long LL;
const int N=210;
template<typename T>inline T chkmax(T A,T B){return A>B?A:B;}
template<typename T>inline T chkmin(T A,T B){return A<B?A:B;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
}
int n,ans[N],dp[8010][8010];
string a[N];
inline int kmp(string a,string b)
{
	int la=a.length(),lb=b.length();
	if(abs(la-lb)>8)return 9;
	For(i,1,la)dp[i][0]=i;
	For(i,1,lb)dp[0][i]=i;
	For(i,1,la)
		For(j,1,lb)
		{
			if(a[i-1]==b[j-1])
				dp[i][j]=chkmin(dp[i-1][j-1],chkmin(dp[i-1][j],dp[i][j-1])+1);
			else
				dp[i][j]=chkmin(dp[i-1][j-1],chkmin(dp[i-1][j],dp[i][j-1]))+1;
		}
	return dp[la][lb];
}
int main()
{
	file();
	read(n);
	For(i,1,n)cin>>a[i];
	For(i,1,n)
		For(j,i+1,n)
		{
			int x=kmp(a[i],a[j]);
			if(x<=8)ans[x]++;
		}
	For(i,1,8)printf("%d ",ans[i]);
	puts("");
	return 0;
}
