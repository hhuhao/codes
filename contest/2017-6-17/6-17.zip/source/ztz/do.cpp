#include<vector>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
using namespace std;
typedef long long LL;
const int N=100010;
const int inf=0x3f3f3f3f;
template<typename T>inline T chkmax(T A,T B){return A>B?A:B;}
template<typename T>inline T chkmin(T A,T B){return A<B?A:B;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
}
int n,Q,k;
int fa[N][19];
int deg[N],dep[N],pos[N],Maxdep[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
int q[N<<1],rmq[N<<1][19],B2[N<<1],dfs_cnt;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
void dfs_dep(int u,int f)
{
	dep[u]=dep[f]+1;
	Maxdep[u]=dep[u];
	q[++dfs_cnt]=u;
	pos[u]=dfs_cnt;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs_dep(v,u);
		Maxdep[u]=chkmax(Maxdep[u],Maxdep[v]);
		q[++dfs_cnt]=u;
	}
}
inline void rmq_init()
{
	For(i,2,dfs_cnt)
		if(i>=(1<<(B2[i-1]+1)))B2[i]=B2[i-1]+1;
		else B2[i]=B2[i-1];
	For(i,1,dfs_cnt)rmq[i][0]=q[i];
	For(j,1,18)
		For(i,1,dfs_cnt-(1<<j)+1)
		{
			if(dep[rmq[i][j-1]]<dep[rmq[i+(1<<(j-1))][j-1]])
				rmq[i][j]=rmq[i][j-1];
			else
				rmq[i][j]=rmq[i+(1<<(j-1))][j-1];
		}
}
inline int Get_lca(int x,int y)
{
	x=pos[x],y=pos[y];
	if(x>y)swap(x,y);
	int k=B2[y-x+1];
	if(dep[rmq[x][k]]<dep[rmq[y-(1<<k)+1][k]])
		return rmq[x][k];
	return rmq[y-(1<<k)+1][k];
}
inline int Get_dis(int x,int y){return dep[x]+dep[y]-(dep[Get_lca(x,y)]<<1);}
inline void init(int root)
{
	dfs_dep(root,0);
	rmq_init();
}
inline void Bf()
{
	int x,dis[N];
	while(Q--)
	{

		read(k);
		read(x);
		For(i,1,n)dis[i]=Get_dis(x,i);
		k--;
		while(k--)
		{
			read(x);
			For(i,1,n)
				dis[i]=chkmin(dis[i],Get_dis(x,i));
		}
		int ans=0;
		For(i,1,n)ans=chkmax(ans,dis[i]);
		printf("%d\n",ans);
	}
}
inline bool itischain()
{
	int cnt1=0,cnt2=0;
	For(i,1,n)
	{
		if(deg[i]==1)++cnt1;
		if(deg[i]==2)++cnt2;
	}
	if(cnt1==2&&cnt2==n-2)return 1;
	return 0;
}
inline bool cmp(int x,int y){return dep[x]<dep[y];}
inline void solve1()
{
	For(i,1,n)
		if(deg[i]==1)
		{
			init(i);
			break;
		}
	int x;
	vector<int>s;
	while(Q--)
	{
		read(k);
		s.clear();
		while(k--)
		{
			read(x);
			s.push_back(x);
		}
		sort(s.begin(),s.end(),cmp);
		int ans=dep[s[0]]-1;
		For(i,1,s.size()-1)
			ans=chkmax(ans,(dep[s[i]]-dep[s[i-1]])/2);
		ans=chkmax(ans,n-dep[s[s.size()-1]]);
		printf("%d\n",ans);
	}
}
void dfs(int u,int f)
{
	fa[u][0]=f;
	For(i,1,18)
	{
		if(!fa[u][i-1])break;
		fa[u][i]=fa[fa[u][i-1]][i-1];
	}
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
	}

}
inline int Get_fa(int x,int k)
{
	For(i,0,18)if(k&(1<<i))x=fa[x][i];
	return x;
}
inline int Get_ans(int x,int y,int k,vector<int>s)
{
	int ret=inf,lca=Get_lca(x,y),now;
	int dis1=dep[x]-dep[lca],dis2=dep[y]-dep[lca];
	if(dis1>=k)
		now=Get_fa(x,k);
	else
		now=Get_fa(y,dis1+dis2-k);
	For(i,0,s.size()-1)ret=chkmin(ret,Get_dis(now,s[i]));
	return ret;
}
inline void solve2()
{
	vector<int>s;int x,sz;
	dfs(1,0);
	while(Q--)
	{
		read(k);
		s.clear();
		while(k--)read(x),s.push_back(x);
		sz=s.size()-1;
		int ans=0;
		For(i,0,sz)
		{
			int flag=1;
			For(j,0,sz)
			if(i!=j)
			{
				int lca=Get_lca(s[i],s[j]);
				if(lca==s[i])
				{
					flag=0;
					break;
				}
			}
			if(flag)
			{
				printf("can: %d\n",s[i]);
				ans=Maxdep[s[i]]-dep[s[i]];
			}
		}
		For(i,0,sz)
		{
			For(j,0,sz)
			{
				int x=s[i],y=s[j];
				int dis=Get_dis(x,y);
				ans=chkmax(ans,Get_ans(x,y,dis>>1,s));
				if(dis&1)ans=chkmax(ans,Get_ans(x,y,(dis>>1)+1,s));
			}
		}
		printf("%d\n",ans);
	}
}
int main()
{
	file();
	int x,y;
	read(n);read(Q);
	For(i,2,n)
	{
		read(x),read(y),deg[x]++,deg[y]++;
		add_edge(x,y),add_edge(y,x);
	}
	/*
	For(i,1,n)printf("%d %d\n",i,dep[i]);
	For(i,1,dfs_cnt)printf("%d ",q[i]);
	puts("");
	For(i,1,n)printf("%d ",pos[i]);
	puts("");
	For(i,1,n)
		For(j,i+1,n)
				printf("%d %d lca:%d dis:%d\n",i,j,Get_lca(i,j),Get_dis(i,j));
	*/
	if(itischain())
		solve1();
	else
	if(n<=3000)init(1),Bf();
	else init(1),Bf();
	return 0;
}
