#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
using namespace std;
typedef long long LL;
const LL mod=99991;
const int N=100010;
template<typename T>inline T chkmax(T A,T B){return A>B?A:B;}
template<typename T>inline T chkmin(T A,T B){return A<B?A:B;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
}
int n,k;
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
const LL inv2=qpow(2,mod-2);
const LL inv4=qpow(4,mod-2);
LL a[N],f0,f1,c1,c2,ans,dp[2][N];
int main()
{
	file();
	read(n),read(k);
	For(i,1,n)read(a[i]);
	read(f0),read(f1);
	c1=(f0+f1)*inv4%mod;
	c2=((3*f0-f1)*inv4%mod+mod)%mod;
	dp[0][0]=c1;
	For(i,1,n)
	{
		int now=(i&1)^1,nxt=i&1;
		LL x=qpow(3,a[i]);
		dp[nxt][0]=dp[now][0];
		For(j,0,k-1)dp[nxt][j+1]=dp[now][j+1]+dp[now][j]*x%mod;
	}
	ans=dp[n&1][k];
	mem(dp[0],0);
	dp[0][0]=c2;
	For(i,1,n)
	{
		int now=(i&1)^1,nxt=i&1;
		LL x=qpow(mod-1,a[i]);
		dp[nxt][0]=dp[now][0];
		For(j,0,k-1)dp[nxt][j+1]=dp[now][j+1]+dp[now][j]*x%mod;
	}
	ans=(ans+dp[n&1][k])%mod;
	printf("%lld\n",ans);
	return 0;
}
