#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<vector>
#include<queue>
using namespace std;

const int maxn=1e5+10;
int n,q,fa[maxn],depth[maxn];
int cnt,table[maxn<<1][20],first[maxn];
vector<int> g[maxn],vec;

int minn(int a,int b){
	if(a<=b)return a;
	return b;
}
int maxx(int a,int b){
	if(a>=b)return a;
	return b;
}
void checkmin(int&a,int b){
	if(a>b)a=b;
}
void checkmax(int&a,int b){
	if(a<b)a=b;
}
void dfs(int pos){
	first[pos]=++cnt;
	depth[pos]=depth[fa[pos]]+1;
	table[cnt][0]=depth[pos];
	for(int i=0,nxt;i<g[pos].size();++i)
		if((nxt=g[pos][i])!=fa[pos]){
			fa[nxt]=pos;
			dfs(nxt);
			table[++cnt][0]=depth[pos];
		}
}
void rmq(){
	for(int j=1;(1<<j)<=cnt;++j)
		for(int i=cnt-(1<<j)+1;i;--i)
			table[i][j]=minn(table[i][j-1],table[i+(1<<j-1)][j-1]);
}
int lca(int u,int v){
	int a=first[u],b=first[v];if(a>b)swap(a,b);
	int k=log(b-a+1)/log(2);
	return minn(table[a][k],table[b+1-(1<<k)][k]);
}
namespace plan2{
	int repos[maxn];
	int main(){
		for(int i=1;i<=n;++i)
			if(g[i].size()>2)
				return 0;
		for(int i=1;i<=n;++i){
			if(g[i].size()>1)continue;
			repos[i]=1;
			for(int cnt=1;cnt<n;){
				for(int j=0;j<g[i].size();++j)
					if(!repos[g[i][j]]){
						i=g[i][j];
						break;
					}
				repos[i]=++cnt;
			}
			break;
		}
		while(q--){
			int k;
			scanf("%d",&k);
			vec.clear();
			for(int i=1,t;i<=k;++i){
				scanf("%d",&t);
				vec.push_back(repos[t]);
			}
			sort(vec.begin(),vec.end());
			int ans=maxx(vec[0]-1,n-vec[k-1]);
			for(int i=1;i<k;++i)
				checkmax(ans,(vec[i]-vec[i-1])/2);
			printf("%d\n",ans);
		}
		exit(0);
	}
}
namespace plan3{
	int main(){
		while(q--){
			memset(depth,-1,sizeof(depth));
			int k,ans=0;
			queue<int> que;
			scanf("%d",&k);
			for(int i=1,t;i<=k;++i){
				scanf("%d",&t);
				depth[t]=0;
				que.push(t);
			}
			while(!que.empty()){
				int pos=que.front();que.pop();
				ans=depth[pos];
				for(int i=0;i<g[pos].size();++i)
					if(depth[g[pos][i]]==-1){
						depth[g[pos][i]]=depth[pos]+1;
						que.push(g[pos][i]);
					}
			}
			printf("%d\n",ans);
		}
		exit(0);
	}
}

int main(){
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	plan2::main();
	if(q<=10)plan3::main();
	dfs(1);
	rmq();
	while(q--){
		vec.clear();
		int k,ans=0;
		scanf("%d",&k);
		for(int i=1,t;i<=k;++i){
			scanf("%d",&t);
			vec.push_back(t);
		}
		for(int i=1;i<=n;++i){
			int res=1e9;
			for(int j=0;j<k&&res>ans;++j)
				checkmin(res,depth[i]+depth[vec[j]]-2*lca(i,vec[j]));
			checkmax(ans,res);
		}
		printf("%d\n",ans);
	}
	return 0;
}
