#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

const int maxn=2e2+10,maxlen=1e6+10;
int n,len[maxn],ans[10],dp[2][maxlen];
char temps[maxlen],*s[maxn];

int minn(int a,int b){
	return a<=b?a:b;
}
void work(int x,int y){
	for(int i=0;i<=len[y];++i)
		dp[0][i]=i;
	for(int i=0,ii;i<len[x];++i){
		dp[(ii=i&1)^1][0]=i+1;
		for(int j=0;j<len[y];++j)
			dp[ii^1][j+1]=minn(dp[ii][j]+(s[x][i]!=s[y][j]),minn(dp[ii^1][j],dp[ii][j+1])+1);
	}
	if(dp[len[x]&1][len[y]]<=8)
		++ans[dp[len[x]&1][len[y]]];
}

int main(){
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%s",temps);
		s[i]=new char[(len[i]=strlen(temps))+10];
		strcpy(s[i],temps);
	}
	for(int i=1;i<=n;++i)
		len[i]=strlen(s[i]);
	for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			work(i,j);
	for(int i=1;i<=8;++i)
		printf("%d ",ans[i]);
	puts("");
	return 0;
}
