#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

const int maxn=1e2+10,mod=99991;
int n,k,f0,f1,a[maxn];

struct matrix{
	short lenx,leny;
	int x[2][2];
	matrix(){}
	matrix(int a,int b){
		lenx=a;leny=b;
		memset(x,0,sizeof(x));
	}
	void e(){
		x[0][0]=x[1][1]=1;
	}
	void operator+= (matrix o){
		for(int i=0;i<lenx;++i)
			for(int j=0;j<leny;++j){
				x[i][j]+=o.x[i][j];
				if(x[i][j]>mod)x[i][j]-=mod;
			}
	}
	matrix operator* (matrix o){
		matrix res(lenx,o.leny);
		for(int i=0;i<lenx;++i)
			for(int j=0;j<o.leny;++j){
				for(int k=0;k<leny;++k)
					res.x[i][j]+=(long long)x[i][k]*o.x[k][j]%mod;
				res.x[i][j]%=mod;
			}
		return res;
	}
}base(2,2),begin(1,2),ans(1,2),f[maxn][maxn],ap[maxn];
matrix qpow(matrix a,long long n){
	matrix res(a.lenx,a.lenx);
	res.e();
	while(n){
		if(n&1ll)res=res*a;
		a=a*a;
		n>>=1;
	}
	return res;
}
matrix dfs(int m,int last){
	if(f[m][last].lenx)
		return f[m][last];
	f[m][last].lenx=f[m][last].leny=2;
	for(int i=n-m;i>=last;--i)
		f[m][last]+=dfs(m-1,i+1)*ap[i];
	return f[m][last];
}

int main(){
	base.x[0][1]=3;base.x[1][0]=1;base.x[1][1]=2;
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=0;i<n;++i)
		scanf("%d",&a[i]),ap[i]=qpow(base,a[i]);
	scanf("%d%d",&f0,&f1);
	begin.x[0][0]=f0;begin.x[0][1]=f1;
	for(int i=0;i<=n;++i)
		f[0][i].e(),f[0][i].lenx=f[0][i].leny=2;
	ans=begin*dfs(k,0);
	printf("%d\n",ans.x[0][0]);
	return 0;
}
