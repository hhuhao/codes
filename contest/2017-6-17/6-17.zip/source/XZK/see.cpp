#include<cstdio>
using namespace std;
const long long md=99991;
int a[100100];
long long powd(long long x,int y){
	long long ans=1;
	while(y)
	{
		if(y&1) ans=ans*x%md;
		x=x*x%md;
		y>>=1;
	}
	return ans;
}
long long g[100100],gg[100100];
int main()
{
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	long long f0,f1;
	scanf("%lld%lld",&f0,&f1);
	long long a1,a2;
	g[0]=1;
	gg[0]=1;
	for(int i=1;i<=n;i++)
	{
		a1=powd(3,a[i])%md;
		a2=powd(md-1,a[i])%md;
		for(int j=k;j>=1;j--)
		{
			(g[j]+=g[j-1]*a1%md)%=md;
			(gg[j]+=gg[j-1]*a2)%=md;
		}
	}
	long long x,y,inv;
	inv=powd(4,md-2);
	x=(f0+f1)%md*inv%md;
	y=(f0*3-f1+md)%md*inv%md;
	long long ans=(x*g[k]%md+y*gg[k]%md)%md;
	printf("%lld\n",ans);
	return 0;
}
