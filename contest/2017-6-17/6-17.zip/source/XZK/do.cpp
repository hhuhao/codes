#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int INF=1e9;
int Min(int x,int y){
	return x<y?x:y;
}
int beg[100100],nex[200100],tto[200100],e;
void putin(int s,int t)
{
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
int fa[100100];
int ask[100100];
bool vis[100100];
int d[100100],dd[100100],f[100100];
int ans;
void dfs_csh(int u)
{
	for(int i=beg[u];i;i=nex[i])
	{
		if(tto[i]==fa[u]) continue;
		fa[tto[i]]=u;
		dfs_csh(tto[i]);
	}
}
void updata(int u,int v,int ff){
	if(v<d[u])
	{
		d[u]=v;
		f[u]=ff;
	}
	else if(v<dd[u])
		dd[u]=v;
}
void getd(int u)
{
	d[u]=dd[u]=INF,f[u]=0;
	if(vis[u]) d[u]=0,f[u]=u;
	for(int i=beg[u];i;i=nex[i])
	{
		if(tto[i]==fa[u]) continue;
		getd(tto[i]);
		updata(u,d[tto[i]]+1,tto[i]);
	}
}
void getf(int u)
{
	if(d[u]>ans) ans=d[u];
	for(int i=beg[u];i;i=nex[i])
	{
		if(tto[i]==fa[u]) continue;
		if(f[u]==tto[i])
			updata(tto[i],dd[u]+1,u);
		else
			updata(tto[i],d[u]+1,u);
		getf(tto[i]);
	}
}
int stk[100100],top;
int mp[100100];
void dfs_line(int u)
{
	stk[++top]=u;
	mp[u]=top;
	for(int i=beg[u];i;i=nex[i])
	{
		if(tto[i]==fa[u]) continue;
		fa[tto[i]]=u;
		dfs_line(tto[i]);
	}
}
int Max(int x,int y){
	return x>y?x:y;
}
void mian(int n,int m,int s)
{
	dfs_line(s);
	int k;
	int t;
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&k);
		for(int j=1;j<=k;j++)
		{
			scanf("%d",&ask[j]);
			ask[j]=mp[ask[j]];
		}
		ans=0;
		sort(ask+1,ask+k+1);
		if(ask[1]-1>ans) ans=ask[1]-1;
		for(int j=2;j<=k;j++)
		{
			t=(ask[j]+ask[j-1])>>1;
			ans=Max(ans,Min(ask[j]-t,t-ask[j-1]));
		}
		ans=Max(ans,n-ask[k]);
		printf("%d\n",ans);
	}
}
int deg[100100];
int main()
{
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	int n;
	int m,k;
	scanf("%d",&n);
	scanf("%d",&m);
	int s,t;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
		deg[s]++,deg[t]++;
	}
	s=-1;
	for(int i=1;i<=n;i++)
	{
		if(deg[i]>2)
		{
			s=-1;
			break;
		}
		if(deg[i]==1)
			s=i;
	}
	if(s!=-1)
	{
		mian(n,m,s);
		return 0;
	}
	dfs_csh(1);
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&k);
		for(int j=1;j<=k;j++)
		{
			scanf("%d",&ask[j]);
			vis[ask[j]]=1;
		}
		ans=0;
		getd(1);
		getf(1);
		printf("%d\n",ans);
		for(int j=1;j<=k;j++)
			vis[ask[j]]=0;
	}
	return 0;
}

