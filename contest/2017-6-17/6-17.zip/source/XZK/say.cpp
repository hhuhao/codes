#include<cstdio>
#include<iostream>
#include<ctime>
#include<vector>
#include<cstring>
using namespace std;
vector<char> str[210];
int len[210],stp[210];
char strr[1000100];
int ans[20];
int Min(int x,int y){
	return x<y?x:y;
}
int la;
int Abs(int x){
	return x>=0?x:-x;
}
int k=0;
const int maxn=1e6+1000;
int a[maxn],b[maxn],c[maxn];
int cnta[maxn],cntb[maxn];
int sa[maxn],rk[maxn];
int hi[maxn][21];
char ss[maxn];
int ll;
void getsa()
{
	int n=ll;
	for(int i=1;i<=n;i++)
		c[ss[i]-'a']++;
	for(int i=1;i<=26;i++)
		c[i]+=c[i-1];
	for(int i=n;i>=1;i--)
		sa[c[ss[i]-'a']--]=i;
	rk[sa[1]]=1;
	for(int i=2;i<=n;i++)
	{
		rk[sa[i]]=rk[sa[i-1]];
		if(ss[sa[i]]!=ss[sa[i-1]]) rk[sa[i]]++;
	}
	for(int l=1;rk[sa[n]]<n;l<<=1)
	{
		for(int i=0;i<=n;i++)
			cnta[i]=cntb[i]=0;
		for(int i=1;i<=n;i++)
		{
			cnta[a[i]=rk[i]]++;
			cntb[b[i]=((i+l<=n?rk[i+l]:0))]++;
		}
		for(int i=1;i<=n;i++)
		{
			cnta[i]+=cnta[i-1];
			cntb[i]+=cntb[i-1];
		}
		for(int i=n;i>=1;i--)
			c[cntb[b[i]]--]=i;
		for(int i=n;i>=1;i--)
			sa[cnta[a[c[i]]]--]=c[i];
		rk[sa[1]]=1;
		for(int i=2;i<=n;i++)
		{
			rk[sa[i]]=rk[sa[i-1]];
			if(a[sa[i]]!=a[sa[i-1]]||b[sa[i]]!=b[sa[i-1]])
				rk[sa[i]]++;
		}
	}
	int st=0;
	for(int i=1;i<=n;i++)
	{
		if(st) st--;
		while(ss[i+st]==ss[sa[rk[i]-1]+st]) st++;
		hi[rk[i]-1][0]=st;
	}
	for(int j=1;j<=20;j++)
		for(int i=1;i<=n;i++)
		{
			if(i+(1<<(j-1))>n) break;
			hi[i][j]=Min(hi[i][j-1],hi[i+(1<<(j-1))][j-1]);
		}
}
int lg2[maxn];
int rmq(int s,int t)
{
	s=rk[s],t=rk[t];
	if(s>t) swap(s,t);
	int p=lg2[t-s];
	int q=t-(1<<p);
	return Min(hi[s][p],hi[q][p]);
}
void dfs(int aa,int bb,int s,int t,int v)
{
	if(s>=len[aa]&&t>=len[bb])
	{
		if(v<la) la=v;
		return;
	}
	if(v+Abs(len[aa]-s-len[bb]+t)>=la) return;
	int q=Min(Min(rmq(stp[aa]+s+1,stp[bb]+t+1),len[aa]-s),len[bb]-t);
	t+=q,s+=q;
	if(s>=len[aa]&&t>=len[bb])
	{
		if(v<la) la=v;
		return;
	}
	if(s<len[aa]&&t<len[bb])
		dfs(aa,bb,s+1,t+1,v+1);
	if(t<len[bb])
		dfs(aa,bb,s,t+1,v+1);
	if(s<len[aa])
		dfs(aa,bb,s+1,t,v+1);
}
int main()
{
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",strr+1);
		len[i]=strlen(strr+1);
		stp[i]=ll+1;
		for(int j=1;j<=len[i];j++)
		{
			str[i].push_back(strr[j]);
			ss[++ll]=strr[j];
		}
		len[i]--;
		k+=len[i];
	}
	lg2[0]=-1;
	for(int i=2;i<=ll+3;i++)
		lg2[i]=lg2[i>>1]+1;
	getsa();
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
		{
			la=9;
			dfs(i,j,-1,-1,0);
			if(la>=1&&la<=8)
				ans[la]++;
		}
	for(int i=1;i<=8;i++)
		printf("%d ",ans[i]);
	printf("\n");
	return 0;
}

