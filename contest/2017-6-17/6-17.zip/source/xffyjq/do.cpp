#include <bits/stdc++.h>

using namespace std;

#define rep(i, l, r) for(int i = l, i##end = r; i <= i##end; ++i)
#define drep(i, l, r) for(int i = l, i##end = r; i >= i##end; --i)
#define erep(i, u) for(int i = head[u], v = to[i]; i; i = nxt[i], v = to[i])
#define ms(a, b) memset(a, b, sizeof a);

template<class T> inline bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template<class T> inline bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

template<typename T> inline T& read(T& x)
{
    static char c; bool flag = 0;
    while(!isdigit(c = getchar())) if(c == '-') flag = 1;
    for(x = c - '0'; isdigit(c = getchar()); (x *= 10) += c - '0');
    if(flag) x = -x; return x;
}

const int maxn = 3010, INF = 0x3f3f3f3f;

int n, q, k;
int a[maxn];

int head[maxn], nxt[maxn << 1], to[maxn << 1], e;
void ae(int x, int y) { to[++e] = y; nxt[e] = head[x]; head[x] = e; }

namespace HLD
{
    int fa[maxn], dep[maxn], son[maxn], sz[maxn], top[maxn];
    
    void dfs1(int u)
    {
        sz[u] = 1; son[u] = 0;
        erep(i, u) if(v != fa[u])
        {
            fa[v] = u; dep[v] = dep[u] + 1;
            dfs1(v); if(sz[v] > sz[son[u]]) son[u] = v;
            sz[u] += sz[v];
        }
    }

    void dfs2(int u, int g)
    {
        top[u] = g;
        if(son[u]) dfs2(son[u], g);
        erep(i, u) if(v != fa[u] && v != son[u]) dfs2(v, v);
    }

    int LCA(int x, int y)
    {
        while(top[x] != top[y])
        {
            if(dep[top[x]] < dep[top[y]]) swap(x, y);
            x = fa[top[x]];
        }
        return dep[x] < dep[y] ? x : y;
    }
}
using namespace HLD;

bool chk_chain()
{
    static bool book[maxn]; ms(book, 0);
    int cnt = 0;
    rep(i, 1, n) if(!book[top[i]])
    {
        book[top[i]] = 1;
        if(++cnt > 2) return 0;
    }
    return 1;
}

namespace chain
{
    int t[maxn];

    int dfs(int u, int pre)
    {
        erep(i, u) if(v != pre) return dfs(v, u);
        return u;
    }

    bool cmp(int x, int y) { return t[x] < t[y]; }

    void solve()
    {
        int st = dfs(1, 0), ed, h = st, pre = 0;
        rep(i, 1, n)
        {
            t[h] = i;
            erep(j, h) if(v != pre) { pre = h, h = v; break; }
        }
        ed = h;
        while(q--)
        {
            read(k); int ans = 0;
            rep(i, 1, k) read(a[i]);
            sort(a + 1, a + k + 1, cmp);
            rep(i, 1, k - 1) chkmax(ans, (dep[a[i]] + dep[a[i + 1]] - 2 * dep[LCA(a[i], a[i + 1])]) / 2);
            chkmax(ans, dep[st] + dep[a[1]] - 2 * dep[LCA(st, a[1])]);
            chkmax(ans, dep[ed] + dep[a[k]] - 2 * dep[LCA(ed, a[k])]);
            printf("%d\n", ans);
        }
    }
}

int main()
{
    freopen("do.in", "r", stdin); freopen("do.out", "w", stdout);
    read(n); read(q); int u, v;
    rep(i, 1, n - 1) read(u), read(v), ae(u, v), ae(v, u);
    dfs1(1); dfs2(1, 1);
    if(chk_chain()) chain::solve(), exit(0);
    while(q--)
    {
        read(k); int ans = 0;
        rep(i, 1, k) read(a[i]);
        rep(i, 1, n)
        {
            int dis = INF;
            rep(j, 1, k) chkmin(dis, dep[i] + dep[a[j]] - 2 * dep[LCA(i, a[j])]);
            chkmax(ans, dis);
        }
        printf("%d\n", ans);
    }

    return 0;
}
