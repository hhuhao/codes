#include <bits/stdc++.h>

using namespace std;

#define rep(i, l, r) for(int i = l, i##end = r; i <= i##end; ++i)
#define drep(i, l, r) for(int i = l, i##end = r; i >= i##end; --i)
#define ms(a, b) memset(a, b, sizeof a);

template<class T> inline bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template<class T> inline bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }

template<typename T> inline T& read(T& x)
{
    static char c; bool flag = 0;
    while(!isdigit(c = getchar())) if(c == '-') flag = 1;
    for(x = c - '0'; isdigit(c = getchar()); (x *= 10) += c - '0');
    if(flag) x = -x; return x;
}

typedef long long LL;

const int maxn = 100010, mo = 99991;

int n, m, a[maxn], f0, f1;

struct Matrix
{
    int M[3][3];

    Matrix() { ms(M, 0); }
} mat, one;

int ans;

Matrix mul(Matrix x, Matrix y)
{
    Matrix ret;
    rep(i, 1, 2) rep(j, 1, 2) rep(k, 1, 2)
        (ret.M[i][j] += (1ll * x.M[i][k] * y.M[k][j]) % mo) %= mo;
    return ret;
}

Matrix fpm(Matrix x, LL k)
{
    Matrix ret;
    ret.M[1][1] = ret.M[2][2] = 1;
    for(; k; k >>= 1, x = mul(x, x)) if(k & 1) ret = mul(ret, x);
    return ret;
}

int main()
{
    freopen("see.in", "r", stdin); freopen("see.out", "w", stdout);
    read(n); read(m);
    rep(i, 1, n) read(a[i]);
    read(f0), read(f1);
    mat.M[1][1] = f0, mat.M[1][2] = f1;
    one.M[1][1] = 2, one.M[1][2] = 1, one.M[2][1] = 3;
    rep(s, 0, (1 << n) - 1) if(__builtin_popcount(s) == m)
    {
        LL sum = 0;
        rep(i, 1, n) if(s & (1 << (i - 1))) sum += a[i];
        Matrix tmp = mul(mat, fpm(one, sum - 1));
        (ans += tmp.M[1][1]) %= mo;
    }
    printf("%d\n", ans);

    return 0;
}
