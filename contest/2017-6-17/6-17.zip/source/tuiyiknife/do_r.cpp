#include<cstdio>
#include<cstdlib>
#include<cstirng>
#include<iostream>
using namespace std;
namespace Divide 
{ 
  
}
int main() {	run();}
