#include<cstdio>
#include<cstdlib>
#define NODES(i,u) for(int i=bgn[u]; i; i=nxt[i])
using namespace std;
const int N = 1e5 + 10;
int n, q, f[N], bgn[N], nxt[N<<1], e, to[N<<1]; 
namespace force
{
  inline void add(int x,int y) {to[++e]=y; nxt[e]=bgn[x]; bgn[x]=e;}
  inline void bdd(int x,int y) {add(x,y); add(y,x);}
  inline int ckmn(int x,int y) {return x<y?x:y;}
  inline int ckmx(int x,int y) {return x>y?x:y;}
  inline void read(int &x) 
  { 
    x = 0; char ch=getchar();
    while(ch > '9' || ch < '0') ch = getchar();
    while(ch >= '0' && ch <= '9') x = x * 10 + ch - '0',ch=getchar();
    //scanf("%d",&x);
  }  
  void dfs(int x,int fa) 
  {
	NODES(i,x) {int y=to[i]; if(y==fa) continue; f[y]=ckmn(f[y],f[x]+1); dfs(y,x);}
  }
  void run()
  {
    freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	read(n); read(q); int x,y;
	for(int i=1; i<n; ++i) {read(x); read(y); bdd(x,y);}
   	for(int i=1; i<=q; ++i)
	{
      read(x);
	  for(int j=1; j<=n; ++j) f[j]=n;
      for(int j=1; j<=x; ++j) {read(y); f[y]=0; }
	  int as=0; for(int j=1; j<=n; ++j) as=ckmx(as,f[j]);
	  printf("%d\n",as);
	}
  }
}
using namespace force;
int main() {  run(); }
/*
7 5
5 4
6 5
7 3
7 4
1 5
2 4
1
4
1
6
4
6 5 7 2
5
1 5 4 3 7
2
2 3
*/
