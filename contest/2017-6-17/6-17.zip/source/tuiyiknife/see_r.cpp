#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
inline void read(int &x) 
{ 
  x = 0; char ch=getchar();
  while(ch > '9' || ch < '0') ch = getchar();
  while(ch >= '0' && ch <= '9') x = x * 10 + ch - '0';
}
int main() {}
