#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std; 
int n, ans[10];
//char str[201][5000]; 
namespace guess
{
  void run() 
  {
    freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	scanf("%d",&n); 
    for(int i=1; i<=8; ++i) printf("%d ",0);
  }
}
using namespace guess;
int main() {	run();}
