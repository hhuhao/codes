#include<cstdio>
#include<cstdlib>
#include<cstring>
#define LL long long 
const int N = 100000 + 10; 
const LL mod = 99991;
const int SZ = 3;
using namespace std; 
int n, k; LL a[N], f0, f1, ans, f[N];
struct mat 
{
  LL m[SZ][SZ]; 
  void init() {memset(m,0,sizeof(m));}
  void E() {for(int i=1; i<=2; ++i) m[i][i]=1;}   
} A,B; 
inline void mul(mat a,mat b,mat &c)
{
  c.init();
  for(int i=1; i<=2; ++i)
    for(int j=1; j<=2; ++j)
	  for(int k=1; k<=2; ++k)
	    (c.m[i][k]+=a.m[i][j]*b.m[j][k])%=mod;
}
namespace force
{ 
  void calc(long long x) 
  {
    A.init(); B.init(); A.m[1][1]=f0; A.m[1][2]=f1; 
	B.m[1][1]=0; B.m[1][2]=3; B.m[2][1]=1; B.m[2][2]=2;
    while(x) {if(x&1) mul(A,B,A); x>>=1; mul(B,B,B);}
    (ans += A.m[1][1]) %= mod;
  }
  void dfs(int x,int y,LL z) 
  {
    for(int i=y; i<=n; ++i) 
    {
	  if(x<k) dfs(x+1,i+1,z+a[i]); else calc(z+a[i]);
    }
  }
  void run() 
  {
    freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1; i<=n; ++i) scanf("%lld",&a[i]); 
    scanf("%lld%lld",&f0,&f1); f0%=mod; f1%=mod;
	dfs(1,1,0LL); printf("%lld\n",ans);
  }
}
using namespace force;
int main() {  run();}
/*
20 10
125 3162 3261 152 376 238 462 4382 376 4972 16 1872 463 9878 688 308 125 236 3526 543
1223 3412
*/
