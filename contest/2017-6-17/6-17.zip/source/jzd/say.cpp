#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
#define ll long long
#define For(i,j,k) for(register int i=j; i<=(int)k; ++i)
#define Forr(i,j,k) for(register int i=j; i>=(int)k; --i)
#define INF 0x3f3f3f3f
using namespace std;

struct node{
	char s[1000005];
	int len;
}s[205];
int n;
int ans[10005];

inline void file(){
	freopen("say.in", "r", stdin);
	freopen("say.out", "w", stdout);
}

inline void solve(){
	For(i,1,n-1)
		For(j,i+1,n)
			if(s[i].len == s[j].len){
				int cnt=0;
				For(k,0,s[i].len-1)
					if(s[i].s[k] != s[j].s[k])	++cnt;
				++ ans[cnt];
			}
}

int main(){
	file();
	
	scanf("%d", &n);
	For(i,1,n){
		scanf("%s", s[i].s);
		s[i].len = strlen(s[i].s);
	}
	
	solve();
	
	For(i,1,8)
		printf("%d ", ans[i]);
	return 0;
}
/*
5
asxglhxpjdczgmt
sxflkxppkcztnmt
sxglkxpjdzlmt
xglkxxepjdazelmzc
asxglkqmvjddalm
*/
