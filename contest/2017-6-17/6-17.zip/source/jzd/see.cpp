#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
#define ll long long
#define For(i,j,k) for(register int i=j; i<=(int)k; ++i)
#define Forr(i,j,k) for(register int i=j; i>=(int)k; --i)
#define INF 0x3f3f3f3f
#define mo 99991
using namespace std;

int n, K;
int a[100005], f[1000005];
ll sum=0, ans=0;

inline void file(){
	freopen("see.in", "r", stdin);
	freopen("see.out", "w", stdout);
}

bool cmp(ll x, ll y){
	return x>=y;
}

inline void init(){
	For(i,2,sum)
		f[i] = (2*f[i-1]+3*f[i-2])%mo;
}

void dfs(int pos, int cnt, int s){
	if(cnt == K){
		ans = (ans+f[s])%mo;
		return;
	}
	For(i,pos+1,n-K+cnt+1)
		dfs(i, cnt+1, s+a[i]);
}

int main(){
	file();
	
	scanf("%d%d", &n, &K);
	For(i,1,n)
		scanf("%d", &a[i]);
	scanf("%d%d", &f[0], &f[1]);
	
	sort(a+1, a+1+n, cmp);
	For(i,1,K)	sum+=a[i];
	if(sum<=1000000 || (f[0]==1&&f[1]==1))	init();
	else return 0;
	
	For(i,1,n-K+1)
		dfs(i, 1, a[i]);
	
	printf("%lld", ans);
	return 0;
}
/*
4 2
1 2 1 3
1 1


20 10
125 3162 3261 152 376 238 462 4382 376 4972 16 1872 463 9878 688 308 125 236 3526 543
1223 3412
*/
