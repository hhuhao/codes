#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
#define ll long long
#define For(i,j,k) for(register int i=j; i<=(int)k; ++i)
#define Forr(i,j,k) for(register int i=j; i>=(int)k; --i)
#define INF 0x3f3f3f3f
#define mo 99991
using namespace std;

struct link{
	int x, dep;
	bool operator < (link &a)const{
		return dep<a.dep;
	}
};
struct node{
	int v, t;
};
int n, Q, root, Dep;
int size[100005], dep[100005];
int cnt, Begin[200005], Next[200005], To[200005];
bool lian=true;
bool f[100005];
queue<node> q;

inline void read(int &x){
	char c;
	while((c=getchar())<'0' || c>'9');
	x = c-'0';
	while((c=getchar())>='0' && c<='9')
		x = x*10+c-'0';
}

inline void add(int x, int y){
	To[++cnt] = y;
	Next[cnt] = Begin[x];
	Begin[x] = cnt;
	
	To[++cnt] = x;
	Next[cnt] = Begin[y];
	Begin[y] = cnt;
}

void dfs(int node){
	for(register int i=Begin[node]; i; i=Next[i]){
		int v=To[i];
		if(!f[v]){
			f[v] = true;
			dep[v] = dep[node]+1;
			if(dep[v] > Dep)	Dep=dep[v];
			dfs(v);
		}
	}
}

inline void clear(){
	memset(f, 0, sizeof(f));
	while(!q.empty())	q.pop();
}

inline int bfs(){
	int back=0;
	while(!q.empty()){
		int x=q.front().v, t=q.front().t;
		q.pop();
		
		if(t>back)	back=t;
		
		for(register int i=Begin[x]; i; i=Next[i]){
			int v=To[i];
			if(!f[v]){
				f[v] = true;
				q.push((node){v,t+1});
			}
		}
	}
	return back;
}

inline void file(){
	freopen("do.in", "r", stdin);
	freopen("do.out", "w", stdout);
}

int main(){
	file();
	
	int x, y;
	
	read(n), read(Q);
	For(i,1,n-1){
		read(x), read(y);
		add(x, y);
		++size[x], ++size[y];
	}
	
	For(i,1,n)
		if(size[i] >= 3){
			lian = false;
			break;
		}
	
	if(lian){
		int ans, que;
		link a[100005];
		For(i,1,n)
			if(size[i] == 1){
				root = i;
				break;
			}
		f[root] = true;
		dep[root] = 1;
		dfs(root);
		while(Q --){
			ans = 0;
			read(que);
			For(i,1,que){
				read(a[i].x);
				a[i].dep = dep[a[i].x];
			}
			sort(a+1, a+1+que);
			ans = a[1].dep;
			if(Dep-a[que].dep > ans)	ans=Dep-a[que].dep;
			For(i,2,que)
				if((a[i].dep-a[i-1].dep)/2 > ans)	ans=(a[i].dep-a[i-1].dep)/2;
			printf("%d\n", ans);
		}
	}
	else{
		int que, x;
		while(Q --){
			clear();
			read(que);
			For(i,1,que){
				read(x);
				q.push((node){x,0});
				f[x] = true;
			}
			printf("%d\n", bfs());
		}
	}
	return 0;
}
/*
7 5
5 4
6 5
7 3
7 4
1 5
2 4
1
4
1
6
4
6 5 7 2
5
1 5 4 3 7
2 
2 3
*/
