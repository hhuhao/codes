#include<iostream>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
#define For(i,a,b) for(i=(a);i<=(b);++i)
#define rep(i,a,b) for(i=(a);i>=(b);--i)
#define ll long long
#define mm(a,b) memset(a,b,sizeof(a))
#define inf 999999999
using namespace std;
int read(){
	int sum = 0,fg = 1;
	char c = getchar();
	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = sum*10 + c-'0',c = getchar();
	return sum * fg;
}
const int maxn = 200010;
int n, q, Begin[maxn] ,to[maxn], e, Next[maxn];
void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}
int p[maxn] ,dis[maxn];
int vis[maxn] ,max_ans;
void dfs(int h){
	if(p[h])dis[h] = 0;
	vis[h] = 1;
	int v;
	for(int i = Begin[h]; i; i = Next[i]){
		if(!vis[v=to[i]]){
			dfs(v);
			dis[h] = min(dis[h] , dis[v]+1);
		}
	}
}
void dfs2(int h,int fa){
	vis[h] = 1;
	if(fa != -1)dis[h] = min(dis[h], dis[fa] + 1);
	max_ans = max(dis[h], max_ans);
	for(int i = Begin[h]; i;i = Next[i]){
		if(!vis[to[i]]){
			dfs2(to[i], h);
		}
	}
}
int du[maxn] ,deep[maxn];
void dfss(int h){
	vis[h] = 1;
	for(int i = Begin[h];i ;i = Next[i]){
		if(!vis[to[i]]){
			deep[to[i]] = deep[h] + 1;
			dfs(to[i]);
		}
	}
}
int t[maxn] ,cnt;
int main(){
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	int i,j;
	n = read(),q = read();int maxdu = 0;
	For(i, 1, n-1){
		int u = read(),v = read();
		du[u] ++;du[v] ++;maxdu = max(maxdu, max(du[v],du[u]));
		add(u,v),add(v,u);
	}
	while(q --){
		int k = read();
		mm(p, 0);
		mm(vis, 0);
		For(i, 1, k){
			int x = read();
			p[x] = 1;
		}
		For(i, 1, n)dis[i] = inf;
		dfs(1);
		mm(vis, 0);
		max_ans = 0;
		dfs2(1 ,-1);
		printf("%d\n",max_ans);
	}
	return 0;
}
