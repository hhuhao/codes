#include<iostream>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
#define For(i,a,b) for(i=(a);i<=(b);++i)
#define rep(i,a,b) for(i=(a);i>=(b);--i)
#define ll long long
#define mm(a,b) memset(a,b,sizeof(a))
#define inf 999999999
#define mod 99991ll
using namespace std;
ll read(){
	ll sum = 0,fg = 1;
	char c = getchar();
	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = sum*10 + c-'0',c = getchar();
	return sum * fg;
}
const int maxn = 100010;
ll n, q, x[maxn];
struct matrix{
	ll a[3][3];
	matrix(){
		mm(a,0);
		a[1][1] = 2,a[1][2] = 3;
		a[2][1] = 1;
	}
	void init(){
		mm(a,0);
	}
};
matrix operator * (matrix h,matrix t){
	matrix res;
	res.init();
	ll i,j,k;
	For(i, 1, 2){
		For(j, 1, 2){
			For(k, 1, 2){
				res.a[i][j] = (res.a[i][j]%mod + h.a[i][k]%mod*t.a[k][j]%mod)%mod;
			}
		}
	}
	return res;
}
ll f0, f1;
ll solve(ll h){
	matrix s;
	matrix t;
	bool flag = 0;
	while(h){
		if(h % 2 == 1){
			if(!flag){
				flag = 1;
				s = t;
			}
			else s = s*t;
		}
		t = t*t;
		h /= 2;
	}
	return (f1 * s.a[1][1] + f0 * s.a[1][2])%mod;
}
ll p[maxn] ,ans;
void dfs(ll h,ll sum,ll now,ll tot){
	if(sum == h){
		ans = (ans + solve(tot-1))%mod;
		return ;
	}
	ll i;
	For(i, now, n){
		if(!p[i]){
			p[i] = 1;
			dfs(h ,sum+1, i+1,tot + x[i]);
			p[i] = 0;
		}
	}
}
int main(){
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	ll i;
	n = read(),q = read();
	For(i, 1, n){
		x[i] = read();
	}
	f0 = read(),f1 = read();
	dfs(q ,0ll ,1ll ,0ll);
	printf("%lld\n",ans);
	return 0;
}
