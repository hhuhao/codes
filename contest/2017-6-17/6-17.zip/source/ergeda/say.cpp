#include<iostream>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
#define For(i,a,b) for(i=(a);i<=(b);++i)
#define rep(i,a,b) for(i=(a);i>=(b);--i)
#define ll long long
#define mm(a,b) memset(a,b,sizeof(a))
#define inf 999999999
using namespace std;
int read(){
	int sum = 0,fg = 1;
	char c = getchar();
	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = sum*10 + c-'0',c = getchar();
	return sum * fg;
}
const int maxn = 50010;
struct node{
	int b[maxn] ,length;
};
node a[210];
int dp[210][210] ,ans[210];
char s[maxn];
int main(){
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	int i, j;
	int n = read() ,max_len = 0;
	For(i, 1, n){
		scanf("%s",s);
		int len = strlen(s) - 1;
		a[i].length = len+1;
		For(j, 0, len){
			a[i].b[j+1] = s[j]-'a'+1;
		}
	}
	int u, v;
	For(i, 1, n){
		For(j, i+1, n){
			mm(dp ,0);
			int max_ans = 0;
			For(u,1,a[i].length){
				For(v,1,a[j].length){
					if(a[i].b[u] == a[j].b[v]){
						dp[u][v] = dp[u-1][v-1] + 1;
					}
					else dp[u][v] = max(dp[u-1][v] , dp[u][v-1]);
				}
			}
			int x = i,y = j;
			if(a[x].length < a[y].length)swap(x,y);
			ans[a[x].length - dp[a[i].length][a[j].length]]++;
		}
	}
	For(i ,1 ,8)printf("%d\n",ans[i]);
	return 0;
}
