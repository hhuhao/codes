#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
char s[205][100500];
int l[205];
int dp[5050][5050];
int ans[9];
void read(int i)
{
	char ch=getchar();
	while(ch<'a'||ch>'z') ch=getchar();
	int num=0;
	while(ch>='a'&&ch<='z') 
	{
		s[i][++num]=ch;
		ch=getchar();
	}
	l[i]=num;
}
int f(int x,int y)
{
	//memset(dp,0,sizeof(dp));
	dp[0][0]=0;
	dp[0][1]=0;dp[1][0]=0;
	int lx=l[x],ly=l[y];
	for(int i=1;i<=lx;++i)
	{
		for(int j=1;j<=ly;++j)
		{
			if(s[x][i]==s[y][j]) dp[i][j]=dp[i-1][j-1]+1;
			else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
		}
	}
	return max(lx,ly)-dp[lx][ly];
}
int main()
{
	freopen("say.in","r",stdin);
	freopen("say.out","w",stdout);
	int i,j,k,m,n;
	scanf("%d",&n);
	for(i=1;i<=n;++i) read(i);
	for(i=1;i<=n;++i)
	{
		for(j=i+1;j<=n;++j)
		{
			m=f(i,j);
			if(i==1&&j==2) 
			{
				printf("%d",m);
				return 0;
			}
			if(m<=8&&m) ans[m]++;
		}
	}
	for(i=1;i<=8;++i) printf("%d ",ans[i]);
	return 0;
}
/*
5 
asxglhxpjdczgmt
sxflkxppkcztnmt
sxglkxpjdzlmt
xglkxxepjdazelmzc
asxglkqmvjddalm
*/
