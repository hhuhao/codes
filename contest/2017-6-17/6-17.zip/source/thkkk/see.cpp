#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
typedef long long ll;
ll F[2];
ll a[100050];
const ll mod=99991;
ll dp[500050][10];
ll POW(ll a,ll n,ll m)
{
	if(!n) return 1;
	ll ans=POW(a,n>>1,m);
	ans=ans*ans%m;
	if(n&1) ans=ans*a%m;
	return ans;
}
ll f(ll x)
{
	if(x&1) return (F[1]+6*(F[0]+F[1])*((POW(9,(x-1)/2,mod)-1)/8)%mod)%mod;
	else return (F[0]+2*(F[0]+F[1])*((POW(9,(x-2)/2+1,mod)-1)/8)%mod)%mod;
	//return (F[0]+2*(F[0]+F[1])*((POW(9,x/2,mod)-1)/8)%mod)%mod;
	//if(x&1) return (F[1]+6*(F[0]+F[1])*((POW(9,(x-1)/2,mod)-1)/8));
	//else return (F[0]+2*(F[0]+F[1])*((POW(9,(x-2)/2+1,mod)-1)/8));
}
bool vis[200020];
ll n;
/*ll dfs(ll y,ll k)
{
	if(!y&&!k) return 1;
	else if(y<0||!k) return 0;
	if(dp[y][k]) return dp[y][k];
	for(ll i=1;i<=n;++i)
	{
		if(!vis[i])
		{
			vis[i]=1;
			dp[y][k]+=dfs(y-a[i],k-1);
			vis[i]=0;
		}
	}
	return dp[y][k];
}*/
int main()
{
	freopen("see.in","r",stdin);
	freopen("see.out","w",stdout);
	ll i,j,k,m,sum=0;
	//F[0]=F[1]=1;
	scanf("%lld%lld",&n,&k);
	for(i=1;i<=n;++i) scanf("%lld",&a[i]),a[i]%=mod,sum+=a[i];//%%%
	scanf("%lld%lld",&F[0],&F[1]);
	dp[0][0]=1;
	ll p=min(sum,mod);
	for(i=1;i<=n;++i)
	{
		for(j=p;j>=0;--j)
		{
			if(j>=a[i]) for(m=k;m;--m) dp[j][m]+=dp[j-a[i]][m-1]; //(()%mod+mod)%mod
		}
	}
	ll ans=0;
	for(i=1;i<=p;++i)
	{
		//ll u=dfs(i,k);
		if(dp[i][k])
		{
			ans=(ans+f(i)*dp[i][k])%mod;
		}
	}
	printf("%lld",ans);
	return 0;
}
/*
4 2
1 2 1 3
1 1

20 10
125 3162 3261 152 376 238 462 4382 376 4972 16 1872 463 9878 688 308 125 236 3526 543
1223 3412

*/
