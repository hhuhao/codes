#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
struct node
{
	int to,next;
}e[200050];
const int mod=200000;
int head[100050],cnt=0,q[200010];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};
	head[x]=cnt;
	
	e[++cnt]=(node){x,head[y]};
	head[y]=cnt;
}
void read(int &re)
{
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	re=0;
	while(ch<='9'&&ch>='0')
	{
		re=re*10+ch-'0';
		ch=getchar();
	}
}
int du[100050];
int d[100050];
int dep[100050];
bool cmp(int a,int b)
{
	return dep[a]<dep[b];
}
int maxdep=0;
void dfslian(int u,int fa,int D)
{
	dep[u]=D;
	if(D>maxdep) maxdep=D;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v!=fa)
		{
			dfslian(v,u,D+1);
		}
	}
}
int qwe[100050];
int main()
{
	freopen("do.in","r",stdin);
	freopen("do.out","w",stdout);
	int i,j,k,m,n,_,x,y,pdnum,hea=0,tail=1,u,v,maxn=0;
	read(n),read(_);
	pdnum=n;
	for(i=1;i<n;++i)
	{
		read(x),read(y);
		add(x,y);du[x]++,du[y]++;
		if(du[x]==2) pdnum--;
		if(du[y]==2) pdnum--;
	}
	if(pdnum==2)
	{
		puts("yes");
		for(i=1;i<=n;++i) if(du[i]==1) {u=i;break;}
		dfslian(u,u,0);
		while(_--)
		{
			read(k);
			for(i=1;i<=k;++i)
			{
				read(qwe[i]);
			}
			sort(qwe+1,qwe+1+k,cmp);
		//	puts("lala");
			maxn=0;
			if(dep[qwe[1]]>maxn) maxn=dep[qwe[1]];
			for(i=2;i<=k;++i)
			{
				if(((dep[qwe[i]]-dep[qwe[i-1]])>>1)>maxn) maxn=(dep[qwe[i]]-dep[qwe[i-1]])>>1;
			}
			if(maxdep-dep[qwe[k]]>maxn) maxn=maxdep-dep[qwe[k]];
			printf("%d\n",maxn);
		}
		return 0;
	}
	while(_--)
	{
		maxn=0;
		memset(d,-1,sizeof(d));
		read(k);
		hea=0;tail=0;
		for(i=1;i<=k;++i)
		{
			read(x);
			++tail;
			tail=(tail-1)%mod+1;
			q[tail]=x;
			d[x]=0;
		}
		while(hea!=tail)
		{
			hea++;
			hea=(hea-1)%mod+1;
			u=q[hea];
			for(i=head[u];i;i=e[i].next)
			{
				v=e[i].to;
				if(d[v]==-1)
				{
					d[v]=d[u]+1;
					if(d[v]>maxn) maxn=d[v];
					tail++;
					tail=(tail-1)%mod+1;
					q[tail]=v;
				}
			}
		}
		printf("%d\n",maxn);
	}
	
	return 0;
}
/*
12 10
1 2
2 3
5 4
3 4
5 6
6 7
8 7
9 8
10 9
11 10
12 11

*/
