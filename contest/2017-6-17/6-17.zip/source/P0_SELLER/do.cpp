#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<queue>
using namespace std;
const int N=3010;
vector<int> G[100010];
map<int,int> ID;
priority_queue<int> Tr;
int dis[N][N];
int dep[N],f[N];
int Min(int x,int y){
	if(x<y)return x;
	else return y;
}
int Max(int x,int y){
	if(x<y)return y;
	else return x;
}
void dfs(int u){
	for(int i=0,v,i_end=G[u].size();i<i_end;++i){
		if((v=G[u][i])==f[u])continue;
		dep[v]=dep[u]+1;
		f[v]=u;
		dfs(v);
	}
}
int lca(int u,int v){
	int ans=0;
	while(u!=v){
		if(dep[v]>dep[u])++ans,v=f[v];
		else ++ans,u=f[u];
	}
	return ans;
}
int n,m;
int main(){
	freopen("do.in","r",stdin);freopen("do.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;++i){
		int u,v;
		scanf("%d%d",&u,&v);
		G[u].push_back(v);G[v].push_back(u);
	}
	int Be=1,p=1;
	for(int i=1;i<=n;++i)if(G[i].size()==1){Be=i,ID[Be]=1;break;}
	for(int i=1;i<=n;++i)if(G[i].size()>2)goto GE;
	for(int i=G[Be][0];;){
		ID[i]=++p;
		if(G[i][0]!=Be)Be=i,i=G[i][0];
		else if(G[i].size()>1)Be=i,i=G[i][1];
		else break;
	}
	while(m--){
		int t,x,ans=0;
		scanf("%d",&t);
		while(t--)scanf("%d",&x),Tr.push(ID[x]);
		ans=Max(ans,n-Tr.top());
		t=Tr.top();Tr.pop();
		while(!Tr.empty()){
			ans=Max(ans,t-Tr.top()>>1);
			t=Tr.top();Tr.pop();
		}
		ans=Max(ans,t-1);
		printf("%d\n",ans);
	}
	exit(0);
	GE:dfs(1);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			dis[i][j]=lca(i,j);
	while(m--){
		int t,ans=0;
		scanf("%d",&t);
		for(int i=1;i<=n;++i)f[i]=(int)1e9;
		for(int i=1;i<=t;++i){
			int x;
			scanf("%d",&x);
			for(int j=1;j<=n;++j)
				f[j]=Min(f[j],dis[x][j]);
		}
		for(int i=1;i<=n;++i)ans=Max(ans,f[i]);
		printf("%d\n",ans);
	}
	return 0;
}
