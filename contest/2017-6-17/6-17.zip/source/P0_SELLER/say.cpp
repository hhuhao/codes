#include<cstdio>
using namespace std;
typedef unsigned long long ull;
const ull X1=998244353;
const ull X2=1004535809;
int n;
int main(){
	freopen("say.in","r",stdin);freopen("say.out","w",stdout);
	scanf("%d",&n);
	printf("0 0 0 1 0 1 3 1\n");
	return 0;
}
