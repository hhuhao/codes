#include<cstdio>
#include<cstdlib>
using namespace std;
typedef long long ll;
const int mod=99991;
ll FPM(ll a,ll b){
	ll res=1ll;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
int n,k,X0,X1;
ll One[100010],Thr[100010];
int a[100010];
int main(){
	freopen("see.in","r",stdin);freopen("see.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i)
		scanf("%d",a+i);
	scanf("%d%d",&X0,&X1);
	if(k==0)puts("0"),exit(0);
	One[0]=Thr[0]=1;
	for(int i=1;i<=n;++i){
		ll O=FPM(mod-1,a[i]),T=FPM(3,a[i]);
		for(int j=k;j;--j){
			(One[j]+=One[j-1]*O%mod)%=mod;
			(Thr[j]+=Thr[j-1]*T%mod)%=mod;
		}
	}
	ll ans=(3*X0-X1+mod)*One[k]%mod*FPM(4,mod-2)%mod+
		(X0+X1)*Thr[k]%mod*FPM(4,mod-2)%mod;
	printf("%lld\n",ans%mod);
	return 0;
}
